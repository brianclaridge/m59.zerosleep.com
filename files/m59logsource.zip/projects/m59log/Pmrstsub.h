/************************************************************
Module name: PMRstSub.H
Notices: Copyright (c) 1995 Jeffrey Richter
************************************************************/


#if !defined(_PMRSTSUBLIB_)
#define PMRSTSUBAPI __declspec(dllimport)
#else
#define PMRSTSUBAPI __declspec(dllexport)
#endif



#ifdef __cplusplus
extern "C" {
#endif
// External function and variable prototypes
PMRSTSUBAPI BOOL SubclassRichEdit( HWND m59log, HWND editwnd, DWORD ThreadIdPMRestore );
PMRSTSUBAPI BOOL UnsubclassRichEdit( HWND editwnd );
PMRSTSUBAPI BOOL IsSubclassed( HWND editwnd );
PMRSTSUBAPI void SetFilterMessages( BOOL filter );
PMRSTSUBAPI BOOL GetFilterMessages( void );
PMRSTSUBAPI void SetSendOptions( COLORREF, BOOL, BOOL, const char * );
PMRSTSUBAPI void GetSendOptions( COLORREF*, BOOL*, BOOL*, char * );
PMRSTSUBAPI void SetTellOptions( COLORREF, BOOL, BOOL, const char * );
PMRSTSUBAPI void GetTellOptions( COLORREF*, BOOL*, BOOL*, char * );

// The handle of the WH_GETMESSAGE hook
// This data member is shared between the DLL and the 
// application.
PMRSTSUBAPI HHOOK g_hHook;
#ifdef __cplusplus
}
#endif

#define MAX_M59_INSTANCES 10
#define PREFIX_LENGTH 5

//////////////////////// End Of File ////////////////////////
