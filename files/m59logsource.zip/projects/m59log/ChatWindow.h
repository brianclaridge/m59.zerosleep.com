#if !defined(AFX_CHATWINDOW_H__CE8D2741_DF71_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
#define AFX_CHATWINDOW_H__CE8D2741_DF71_11D0_AAC6_0000E8CDA5DB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ChatWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChatWindow dialog

class CChatWindow : public CDialog
{
// Construction
public:
	CChatWindow(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChatWindow)
	enum { IDD = IDD_CHATWINDOW };
	CStatic	m_tell;
	CStatic	m_send;
	BOOL	m_colorchanges;
	BOOL	m_sendbold;
	BOOL	m_senditalic;
	CString	m_sendprefix;
	BOOL	m_tellbold;
	BOOL	m_tellitalic;
	CString	m_tellprefix;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChatWindow)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChatWindow)
	afx_msg void OnTellcolor();
	afx_msg void OnSendcolor();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSendbold();
	afx_msg void OnSenditalic();
	afx_msg void OnTellbold();
	afx_msg void OnTellitalic();
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnChangeSendprefix();
	afx_msg void OnChangeTellprefix();
	afx_msg void OnColorchanges();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void SetBackColor( COLORREF backColor ) { m_backColor = backColor; }

	BOOL GetFilter( void ) const { return m_colorchanges; }
	void SetFilter( BOOL colorchanges ) { m_colorchanges = colorchanges; }

	COLORREF GetSendColor( void ) const { return m_sendColor; }
	COLORREF GetTellColor( void ) const { return m_tellColor; }
	void SetSendOptions( COLORREF sendColor, BOOL sendbold, BOOL senditalic, char *sendPrefix )
			{
				m_sendColor = sendColor;
				m_sendbold = sendbold;
				m_senditalic = senditalic;
				m_sendprefix = sendPrefix;
			}
	void GetSendOptions( COLORREF *sendColor, BOOL *sendbold, BOOL *senditalic, char *sendPrefix ) const
			{
				*sendColor = m_sendColor;
				*sendbold = m_sendbold;
				*senditalic = m_senditalic;
				strcpy( sendPrefix, m_sendprefix );
			}
	void SetTellOptions( COLORREF tellColor, BOOL tellbold, BOOL tellitalic, char *tellPrefix )
			{
				m_tellColor = tellColor;
				m_tellbold = tellbold;
				m_tellitalic = tellitalic;
				m_tellprefix = tellPrefix;
			}
	void GetTellOptions( COLORREF *tellColor, BOOL *tellbold, BOOL *tellitalic, char *tellPrefix ) const
			{
				*tellColor = m_tellColor;
				*tellbold = m_tellbold;
				*tellitalic = m_tellitalic;
				strcpy( tellPrefix, m_tellprefix );
			}

private:
	COLORREF m_sendColor;
	COLORREF m_tellColor;
	COLORREF m_backColor;

	CBrush	m_hbr;
	CFont		*m_sendFont;
	CFont		*m_tellFont;

	LOGFONT	m_baseFont;

	void updateSendFont( void );
	void updateTellFont( void );
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATWINDOW_H__CE8D2741_DF71_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
