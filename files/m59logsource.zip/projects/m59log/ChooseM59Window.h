#if !defined(AFX_CHOOSEM59WINDOW_H__FA180EC1_DD05_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
#define AFX_CHOOSEM59WINDOW_H__FA180EC1_DD05_11D0_AAC6_0000E8CDA5DB__INCLUDED_

#include "PMRstSub.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ChooseM59Window.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChooseM59Window dialog

class CChooseM59Window : public CDialog
{
// Construction
public:
	CChooseM59Window(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChooseM59Window)
	enum { IDD = IDD_CHOOSEWINDOW };
	CListBox	m_windowList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChooseM59Window)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int	m_possible;
	int	m_selected;
	HWND	m_possibles[ MAX_M59_INSTANCES ];

public:
	void SetPossibles( HWND *possibles, int nPossibles );
	int GetSelected( void ) const { return m_selected; }
	// Generated message map functions
	//{{AFX_MSG(CChooseM59Window)
	virtual void OnOK();
	afx_msg void OnShowwindow();
	afx_msg void OnDblclkWindowtitlelist();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHOOSEM59WINDOW_H__FA180EC1_DD05_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
