// m59log.h : main header file for the M59LOG application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CM59logApp:
// See m59log.cpp for the implementation of this class
//

class CM59logApp : public CWinApp
{
public:
	CM59logApp();

	void SaveState( LPRECT rect, BOOL ismaxed );

	BOOL GetRect( LPRECT rect )  { if ( !m_readIni ) readState(); *rect = m_rect; return m_defrect; }
	BOOL GetMaxed( BOOL *maxed ) { if ( !m_readIni ) readState(); *maxed = m_maximize; return m_defrect; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM59logApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CM59logApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	BOOL		GetAutoConnect		( void ) const { return m_autoConnect; }
	BOOL		GetEvenHours		( void ) const { return m_evenhours; }
	void		ToggleAutoConnect	( void )			{ m_autoConnect = !m_autoConnect; }
	void		ToggleEvenHours	( void )			{ m_evenhours   = !m_evenhours; }
	COLORREF	GetPurpleColor		( void ) const { return m_purpleColor; }
	COLORREF	GetBackColor		( void ) const { return m_backColor; }

private:
	BOOL		m_readIni;
	BOOL		m_defrect;
	RECT		m_rect;
	BOOL		m_maximize;
	BOOL		m_autoConnect;
	BOOL		m_evenhours;
	COLORREF	m_purpleColor;
	COLORREF	m_backColor;

	CString	m_meridianPath;

	void readState( void );
	void findPurpleColor( void );
};


/////////////////////////////////////////////////////////////////////////////
