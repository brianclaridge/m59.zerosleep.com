// m59log.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "m59log.h"

#include "MainFrm.h"
#include "m59logDoc.h"
#include "m59logView.h"

#include "pmrstsub.h"

#include "shlobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const char *SETTINGS = "Settings";
const char *WINDOW_POS = "WindowPos";
const char *AUTOCONNECT = "AutoConnect";
const char *MIDNIGHT = "Midnight";
const char *MERIDIAN_PATH = "Meridian Path";
const char *MERIDIAN_INI = "\\meridian.ini";
const char *SYSMESSAGE_COLOR = "Color9";
const char *SYSMESSAGE_COLORFORMAT = "Color%d";
const int MAX_COLOR_INDEX = 23;
const int PURPLE_COLOR_INDEX = 9;
const int TEXT_BG_COLOR_INDEX = 11;

const char *CHAT_SEND_PREFIX = "Send Prefix";
const char *CHAT_SEND_DATA   = "Send Options";
const char *CHAT_TELL_PREFIX = "Tell Prefix";
const char *CHAT_TELL_DATA   = "Tell Options";
const char *CHAT_FILTER      = "Chat Filtering";

/////////////////////////////////////////////////////////////////////////////
// CM59logApp

BEGIN_MESSAGE_MAP(CM59logApp, CWinApp)
	//{{AFX_MSG_MAP(CM59logApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CM59logApp construction

CM59logApp::CM59logApp()
{
	m_readIni = FALSE;
	m_purpleColor = RGB( 128, 0, 128 );
	m_meridianPath = "";
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CM59logApp object

CM59logApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CM59logApp initialization

BOOL CM59logApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.
	SetRegistryKey( "Didsoft" );

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CM59logDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CM59logView));
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	return TRUE;
}

void CM59logApp::readState( void )
{
	CString str = GetProfileString( SETTINGS, WINDOW_POS, NULL );

	if ( str.IsEmpty() )
	{
		m_defrect = FALSE;
	}
	else
	{
		m_defrect = TRUE;

		sscanf(	str,
					"%d %d %d %d %d",
					&m_rect.left,
					&m_rect.top,
					&m_rect.right,
					&m_rect.bottom,
					&m_maximize );
	}

	m_autoConnect	= GetProfileInt( SETTINGS, AUTOCONNECT, TRUE );
	m_evenhours		= GetProfileInt( SETTINGS, MIDNIGHT, TRUE );

	m_meridianPath = GetProfileString( SETTINGS, MERIDIAN_PATH, "c:\\meridian" );

	findPurpleColor();

	// Get the chat window config
	CString sendPrefix = GetProfileString( SETTINGS, CHAT_SEND_PREFIX, "" );
	CString tellPrefix = GetProfileString( SETTINGS, CHAT_TELL_PREFIX, "" );

	COLORREF sendColor, tellColor;
	BOOL sendbold, senditalic;
	BOOL tellbold, tellitalic;

	CString sendData = GetProfileString( SETTINGS, CHAT_SEND_DATA, "0,0,0" );
	sscanf( sendData, "%d,%d,%d", &sendColor, &sendbold, &senditalic );

	CString tellData = GetProfileString( SETTINGS, CHAT_TELL_DATA, "0,0,0" );
	sscanf( tellData, "%d,%d,%d", &tellColor, &tellbold, &tellitalic );

	SetSendOptions( sendColor, sendbold, senditalic, sendPrefix );
	SetTellOptions( tellColor, tellbold, tellitalic, tellPrefix );

	BOOL filter = GetProfileInt( SETTINGS, CHAT_FILTER, FALSE );
	SetFilterMessages( filter );

	m_readIni = TRUE;
}

void CM59logApp::findPurpleColor( void )
{
	char colorString[ 80 ];
	CString meridianIni;
	BOOL found;

	do
	{
		meridianIni = m_meridianPath + MERIDIAN_INI;

		found = ::GetPrivateProfileString(	"Colors",
														SYSMESSAGE_COLOR,
														NULL,
														colorString,
														sizeof colorString,
														meridianIni );

		if ( !found )
		{
			AfxMessageBox( "The program needs to examine your Meridian color settings. Please select the location of Meridian 59", MB_ICONINFORMATION );

			char foldername[ MAX_PATH ];

			BROWSEINFO info = {
										GetActiveWindow(),
										NULL,
										foldername,
										"Locate the Meridian 59 Directory",
										BIF_RETURNONLYFSDIRS,
										NULL,
										0
									};

			LPITEMIDLIST location = SHBrowseForFolder( &info );

			if ( location )
			{
				SHGetPathFromIDList( location, foldername );
				m_meridianPath = foldername;
			}
		}
	} while ( !found );

	// Purple colour set up
	UINT red, green, blue;

	sscanf( colorString, "%u,%u,%u", &red, &green, &blue );
	m_purpleColor = RGB( red, green, blue );

	CString colorKey;

	for ( int color = 0; color <= MAX_COLOR_INDEX; color++ )
	{
		if ( color != PURPLE_COLOR_INDEX )
		{
			colorKey.Format( SYSMESSAGE_COLORFORMAT, color );

			found = ::GetPrivateProfileString(	"Colors",
															colorKey,
															NULL,
															colorString,
															sizeof colorString,
															meridianIni );

			if ( found )
			{
				sscanf( colorString, "%u,%u,%u", &red, &green, &blue );
				COLORREF thisCol = RGB( red, green, blue );

				if ( thisCol == m_purpleColor )
					AfxMessageBox( "Error detected: Your System Messages color is identical to another. Please correct this and restart Meridian 59!", MB_ICONERROR );

				if ( color == TEXT_BG_COLOR_INDEX )
					m_backColor = thisCol;
			}
		}
	}
}

void CM59logApp::SaveState( LPRECT rect, BOOL ismaxed )
{
	CString str;

	str.Format( "%d %d %d %d %d",
					rect->left,
					rect->top,
					rect->right,
					rect->bottom,
					ismaxed );

	WriteProfileString( SETTINGS, WINDOW_POS, str );

	WriteProfileInt( SETTINGS, AUTOCONNECT,	m_autoConnect );
	WriteProfileInt( SETTINGS, MIDNIGHT,		m_evenhours );

	WriteProfileString( SETTINGS, MERIDIAN_PATH, m_meridianPath );

	// Get the chat window config
	char sendPrefix[PREFIX_LENGTH];
	char tellPrefix[PREFIX_LENGTH];
	COLORREF sendColor, tellColor;
	BOOL sendbold, senditalic;
	BOOL tellbold, tellitalic;

	GetSendOptions( &sendColor, &sendbold, &senditalic, sendPrefix );
	GetTellOptions( &tellColor, &tellbold, &tellitalic, tellPrefix );

	WriteProfileString( SETTINGS, CHAT_SEND_PREFIX, sendPrefix );
	WriteProfileString( SETTINGS, CHAT_TELL_PREFIX, tellPrefix );

	CString sendData;
	sendData.Format( "%d,%d,%d", sendColor, sendbold, senditalic );
	WriteProfileString( SETTINGS, CHAT_SEND_DATA, sendData );

	CString tellData;
	tellData.Format( "%d,%d,%d", tellColor, tellbold, tellitalic );
	WriteProfileString( SETTINGS, CHAT_TELL_DATA, tellData );

	WriteProfileInt( SETTINGS, CHAT_FILTER, GetFilterMessages() );
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnMailme();
	afx_msg void OnVisitme();
	afx_msg void OnVisit3do();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_BN_CLICKED(IDC_MAILME, OnMailme)
	ON_BN_CLICKED(IDC_VISITME, OnVisitme)
	ON_BN_CLICKED(IDC_VISIT3DO, OnVisit3do)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CM59logApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CM59logApp commands

void CAboutDlg::OnMailme() 
{
	ShellExecute(	GetSafeHwnd(),
						NULL,
						"mailto:dids@ride.demon.co.uk",
						NULL,
						NULL,
						SW_SHOWNORMAL );
}

void CAboutDlg::OnVisitme() 
{
	ShellExecute(	GetSafeHwnd(),
						NULL,
						"http://www.ride.demon.co.uk/meridian59/m59log.htm",
						NULL,
						NULL,
						SW_SHOWNORMAL );
}

void CAboutDlg::OnVisit3do() 
{
	ShellExecute(	GetSafeHwnd(),
						NULL,
						"http://meridian.3do.com",
						NULL,
						NULL,
						SW_SHOWNORMAL );
}
