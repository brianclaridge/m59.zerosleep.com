// ChooseM59Window.cpp : implementation file
//

#include "stdafx.h"
#include "m59log.h"
#include "ChooseM59Window.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChooseM59Window dialog


CChooseM59Window::CChooseM59Window(CWnd* pParent /*=NULL*/)
	: CDialog(CChooseM59Window::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChooseM59Window)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	memset( m_possibles, 0, sizeof m_possibles );
}


void CChooseM59Window::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChooseM59Window)
	DDX_Control(pDX, IDC_WINDOWTITLELIST, m_windowList);
	//}}AFX_DATA_MAP
}

void CChooseM59Window::SetPossibles( HWND *possibles, int nPossibles )
{
	for ( m_possible = 0; m_possible < nPossibles; m_possible++ )
		m_possibles[ m_possible ] = possibles[ m_possible ];
}

BEGIN_MESSAGE_MAP(CChooseM59Window, CDialog)
	//{{AFX_MSG_MAP(CChooseM59Window)
	ON_BN_CLICKED(IDSHOWWINDOW, OnShowwindow)
	ON_LBN_DBLCLK(IDC_WINDOWTITLELIST, OnDblclkWindowtitlelist)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChooseM59Window message handlers

void CChooseM59Window::OnOK() 
{
	m_selected = m_windowList.GetCurSel();
	
	CDialog::OnOK();
}

void CChooseM59Window::OnShowwindow() 
{
	int selected = m_windowList.GetCurSel();

	::ShowWindow( ::GetParent( m_possibles[ selected ] ), SW_SHOWNORMAL );
	::BringWindowToTop( ::GetParent( m_possibles[ selected ] ) );
}

void CChooseM59Window::OnDblclkWindowtitlelist() 
{
	OnShowwindow();	
}

BOOL CChooseM59Window::OnInitDialog() 
{
	CDialog::OnInitDialog();

	for ( int possible = 0; possible < m_possible; possible++ )
	{
		char title[ 100 ];
		::GetWindowText( ::GetParent( m_possibles[ possible ] ), title, sizeof title );
		m_windowList.AddString( title );
	}

	m_windowList.SetCurSel( 0 );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
