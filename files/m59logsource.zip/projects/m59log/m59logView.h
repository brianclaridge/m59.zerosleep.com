// m59logView.h : interface of the CM59logView class
//
/////////////////////////////////////////////////////////////////////////////

const UINT HINT_RESET_CONTENT = 0xFFFFFFFF;

class CM59logView : public CView
{
protected: // create from serialization only
	CM59logView();
	DECLARE_DYNCREATE(CM59logView)

// Attributes
public:
	CM59logDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM59logView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CM59logView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CM59logView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditCopyallsubtree();
	afx_msg void OnUpdateEditCopyallsubtree(CCmdUI* pCmdUI);
	afx_msg void OnEditCopycompletetree();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void SetCharFormat( UINT flags, const CHARFORMAT *fmt, COLORREF purpleColor );
	void ReplaceSel( LPCTSTR str );

private:
	BOOL			m_systemmessage;
	CTreeCtrl	m_tree;
	HTREEITEM	m_rootitem;
	HTREEITEM	m_deaths;
	HTREEITEM	m_spells;
	HTREEITEM	m_misc;

	void			doTotalDeathScore( void );
	void			doFood( void );
	void			doRests( void );
	void			doKillWhat( void );
	void			doKilledByWhat( void );
	void			doKillWith( void );
	void			doStaff( void );
	void			doPESpells( void );
	void			doAreaSpells( void );
	void			doTouchSpells( void );
	void			doBreaks( void );
	void			doTougher( void );
	void			doTokens( void );
	void			doAssassins( void );
	void			doWeapons( void );
	void			doSicks( void );

	void			resetTree( void );

	void			doKillPerf( const killPerformance &, LPCSTR, HTREEITEM, LPARAM );

	HTREEITEM	insertItem( const CString &str, HTREEITEM parentitem, LPARAM lParamID );

	void			getTreeText( HTREEITEM root, CString &text, bool skipClosed, int depth );
	void			putOnClipboard( const CString &text );
};

#ifndef _DEBUG  // debug version in m59logView.cpp
inline CM59logDoc* CM59logView::GetDocument()
   { return (CM59logDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
