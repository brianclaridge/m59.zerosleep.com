/************************************************************
Module name: PMRstSub.C
Notices: Copyright (c) 1995 Jeffrey Richter
************************************************************/


#include "..\..\AdvWin32.H"    /* See Appendix B for details. */
#include <windows.h>
#include <windowsx.h>

#include <richedit.h>

#pragma warning(disable: 4001)      /* Single-line comment */

#include "PMRstSub.RH"

#define _PMRSTSUBLIB_
#include "..\PMRstSub.H"

/////////////////////////////////////////////////////////////


// Forward references
LRESULT WINAPI GetMsgProc (int nCode, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI M59Subclass (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

/////////////////////////////////////////////////////////////

// Instruct the compiler to put the following variables in
// their own data section called
// Shared. We then instruct the linker that we want to
// share the data in this section with all instances of this
// application.
// Note, you *MUST* initialise the variables, otherwise they don't get shared
#pragma data_seg("Shared")

UINT	g_setChar = 0;

struct INSTANCEDATA
{
	HWND  hwndRichText;
	HWND  m59log;
	DWORD dwThreadIdRestore;

} g_insts[ MAX_M59_INSTANCES ] = {0};

UINT	g_replaceSel = 0;

UINT	g_hookRefCount = 0;
HHOOK g_hRealHook = NULL;
BOOL	g_filterMessages = FALSE;

COLORREF g_sendColor = RGB( 255, 255, 255);
BOOL		g_sendbold = FALSE;
BOOL		g_senditalic = FALSE;
char		g_sendprefix[ PREFIX_LENGTH ] = {""};
COLORREF g_tellColor = RGB( 255, 255, 255 );
BOOL		g_tellbold = FALSE;
BOOL		g_tellitalic = FALSE;
char		g_tellprefix[ PREFIX_LENGTH ] = {""};

#pragma data_seg()

/////////////////////////////////////////////////////////////

// Nonshared variables
PMRSTSUBAPI HHOOK	g_hHook				= NULL;
WNDPROC				g_wpOrigM59Proc	= NULL;
HINSTANCE			g_hinstDll			= NULL;
HWND					g_thisRichText		= NULL;
HWND					g_thism59log		= NULL;

/////////////////////////////////////////////////////////////

BOOL WINAPI DllMain (HINSTANCE hinstDll, DWORD fdwReason, LPVOID lpvReserved)
{

   switch (fdwReason)
	{
      case DLL_PROCESS_ATTACH:
         // DLL is attaching to the address space
         // of the current process.
         g_hinstDll = hinstDll;
         break;

      case DLL_THREAD_ATTACH:
         // A new thread is being created
         // in the current process.
         break;

      case DLL_THREAD_DETACH:
         // A thread is exiting cleanly.
         break;

      case DLL_PROCESS_DETACH:
         // The calling process is detaching the
         // DLL from its address space.
	      if ( g_wpOrigM59Proc != NULL && g_thisRichText != NULL)
				SubclassWindow( g_thisRichText, g_wpOrigM59Proc );
         break;
   }

   return TRUE;
}

/////////////////////////////////////////////////////////////

PMRSTSUBAPI BOOL GetFilterMessages( void )
{
	return g_filterMessages;
}

PMRSTSUBAPI void SetFilterMessages( BOOL filter )
{
	g_filterMessages = filter;
}

PMRSTSUBAPI void SetSendOptions( COLORREF sendColor, BOOL sendbold, BOOL senditalic, const char *sendprefix  )
{
	g_sendColor = sendColor;
	g_sendbold = sendbold;
	g_senditalic = senditalic;
	strcpy( g_sendprefix, sendprefix );
}

PMRSTSUBAPI void GetSendOptions( COLORREF *sendColor, BOOL *sendbold, BOOL *senditalic, char *sendprefix )
{
	*sendColor = g_sendColor;
	*sendbold = g_sendbold;
	*senditalic = g_senditalic;
	strcpy( sendprefix, g_sendprefix );
}

PMRSTSUBAPI void SetTellOptions( COLORREF tellColor, BOOL tellbold, BOOL tellitalic, const char *tellprefix )
{
	g_tellColor = tellColor;
	g_tellbold = tellbold;
	g_tellitalic = tellitalic;
	strcpy( g_tellprefix, tellprefix );
}

PMRSTSUBAPI void GetTellOptions( COLORREF *tellColor, BOOL *tellbold, BOOL *tellitalic, char *tellprefix )
{
	*tellColor = g_tellColor;
	*tellbold = g_tellbold;
	*tellitalic = g_tellitalic;
	strcpy( tellprefix, g_tellprefix );
}

static struct INSTANCEDATA *findFreeSlot( void )
{
	int i;

	for ( i = 0; i < MAX_M59_INSTANCES; i++ )
		if ( g_insts[ i ].hwndRichText == NULL )
			return &g_insts[ i ];

	return NULL;
}

static void clearSlot( struct INSTANCEDATA *clear )
{
	memset( clear, 0, sizeof *clear );
}

static struct INSTANCEDATA *findWindowInst( HWND wnd )
{
	int i;

	for ( i = 0; i < MAX_M59_INSTANCES; i++ )
		if ( g_insts[ i ].hwndRichText == wnd )
			return &g_insts[ i ];

	return NULL;
}

PMRSTSUBAPI BOOL IsSubclassed( HWND editwnd )
{
	// Already sub-classed - fail
	if ( findWindowInst( editwnd ) != NULL )
		return TRUE;
}

PMRSTSUBAPI BOOL SubclassRichEdit ( HWND m59log, HWND editwnd, DWORD dwThreadIdRestore)
{
	struct INSTANCEDATA *inst;

	// Already sub-classed - fail
	if ( IsSubclassed( editwnd ) )
		return FALSE;

	if ( (inst = findFreeSlot()) == NULL )
		return FALSE;

   inst->hwndRichText	= editwnd;
   inst->m59log			= m59log;

	g_setChar = RegisterWindowMessage( "M59HOOK_EM_SETCHARFORMAT" );
	g_replaceSel = RegisterWindowMessage( "M59HOOK_EM_REPLACESEL" );

   if (! IsWindow(inst->hwndRichText))
	{
      // If the Meridian 59 cannot be found,
      // we must terminate.
      MessageBox(	NULL,
						__TEXT("Cannot find the Meridian 59 window!"),
						NULL, MB_OK);

		clearSlot( inst );

      return FALSE;
   }

   // First we must install a systemwide WH_GETMESSAGE hook.
	if ( g_hHook == NULL )
	{
		if ( g_hRealHook == NULL )
			g_hRealHook = SetWindowsHookEx(WH_GETMESSAGE, GetMsgProc, g_hinstDll, 0 );
		g_hHook = g_hRealHook;
		g_hookRefCount++;
	}

   // The hook cannot be installed. (Maybe there is greater
   // security in this environment.)
   if (g_hHook == NULL)
      return FALSE;

   // The hook was installed successfully; force a
   // benign message to the window so that the hook
   // function gets called.
   PostMessage( inst->hwndRichText, WM_NULL, 0, 0);

   // The window in the other process is subclassed.
   inst->dwThreadIdRestore = dwThreadIdRestore;

   return TRUE;
}

PMRSTSUBAPI BOOL UnsubclassRichEdit ( HWND editwnd )
{
	struct INSTANCEDATA *inst;

	if ( --g_hookRefCount == 0 )
	{
		UnhookWindowsHookEx( g_hRealHook );
		g_hRealHook = NULL;
	}

	g_hHook = NULL;

	// Already sub-classed - fail
	if ( (inst = findWindowInst( editwnd )) == NULL )
		return FALSE;
	else
		clearSlot( inst );

	return TRUE;
}

/////////////////////////////////////////////////////////////

LRESULT WINAPI GetMsgProc (int nCode, WPARAM wParam, LPARAM lParam)
{
   static BOOL fM59Subclassed = FALSE;

   if (!fM59Subclassed &&
		nCode == HC_ACTION &&
      wParam == PM_REMOVE &&
      ((MSG *) lParam)->message == WM_NULL)
	{
      // If we have not yet subclassed the Meridian 59
      // and it is retrieving a message
      // and the window handle identifies Meridian 59 
      // and the message is a WM_NULL message
		struct INSTANCEDATA *inst = findWindowInst( ((MSG *) lParam)->hwnd );

		if ( inst )
		{
			// This DLL is now mapped into Meridian 59's
			// address space.  Time to subclass Meridian 59.
			g_thisRichText		= inst->hwndRichText;
			g_wpOrigM59Proc	= SubclassWindow( g_thisRichText, M59Subclass );
			g_thism59log		= inst->m59log;

			fM59Subclassed = TRUE;
		}
   }

   return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}

/////////////////////////////////////////////////////////////

void SendToLog( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, size_t size )
{
	COPYDATASTRUCT cds = { wParam | (msg == g_setChar ? 0x80000000 : 0), size, (void *) lParam };

	if ( g_thism59log && SendMessage( g_thism59log, WM_COPYDATA, (WPARAM) hwnd, (LPARAM) &cds ) == FALSE )
		;
}

/////////////////////////////////////////////////////////////

#define EFFECTS( bold, italic ) (((bold) ? CFM_BOLD : 0) | ((italic) ? CFM_ITALIC : 0))

// Subclass function for the Meridian 59 chat window. Any message for
// the Meridian 59 chat window comes here before reaching the
// original window function.
LRESULT WINAPI M59Subclass (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static BOOL s_gotNL			= FALSE;
	static BOOL s_accepttoEOL	= FALSE;
	static BOOL s_allowThisOne = FALSE;

   switch (uMsg)
	{
      case EM_SETCHARFORMAT:
			if ( !s_allowThisOne )
				SendToLog( hwnd, g_setChar, wParam, lParam, sizeof( CHARFORMAT ) );

			// Drop the colour change if we're filtering them out
			if ( g_filterMessages && !s_gotNL && !s_accepttoEOL && !s_allowThisOne )
				return 1;

         break;

      case EM_REPLACESEL:
			if ( g_filterMessages && !s_allowThisOne )
			{
				if ( strcmp( (char *) lParam, "\r\n" ) == 0 )
				{
					s_gotNL = TRUE;
					s_accepttoEOL = FALSE;
				}
				else
				{
					if ( s_gotNL )
					{
						BOOL		colorChangeNeeded = FALSE;
						COLORREF changeColor;
						DWORD		effects = 0;
						char		prefix[ PREFIX_LENGTH ] = "";

						if ( strstr( (char *) lParam, " tells you," ) )
						{
							s_accepttoEOL = TRUE;
							colorChangeNeeded = TRUE;
							changeColor = g_tellColor;
							effects = EFFECTS( g_tellbold, g_tellitalic );
							strcpy( prefix, g_tellprefix );
						}
						else if ( strstr( (char *) lParam, " sends, " ) )
						{
							s_accepttoEOL = TRUE;
							colorChangeNeeded = TRUE;
							changeColor = g_sendColor;
							effects = EFFECTS( g_sendbold, g_senditalic );
							strcpy( prefix, g_sendprefix );
						}
						else if ( strstr( (char *) lParam, "You broadcast," ) )
							s_accepttoEOL = TRUE;
						else if ( strstr( (char *) lParam, "You send, " ) )
						{
							s_accepttoEOL = TRUE;
							colorChangeNeeded = TRUE;
							changeColor = g_sendColor;
							effects = EFFECTS( g_sendbold, g_senditalic );
							strcpy( prefix, g_sendprefix );
						}
						else if ( strstr( (char *) lParam, "You say, " ) )
							s_accepttoEOL = TRUE;

						if ( colorChangeNeeded )
						{
							CHARFORMAT charFormat =
								{
									sizeof charFormat,
									CFM_COLOR,
									effects,
									0, // x
									0, // y
									changeColor
								};

							if ( effects != 0 )
								charFormat.dwMask |= (CFM_BOLD | CFM_ITALIC);

							s_allowThisOne = TRUE;

							// Change the colour
							SendMessage( hwnd, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM) &charFormat );

							// And add the prefix
							if( strlen( prefix ) > 0 )
								SendMessage( hwnd, EM_REPLACESEL, wParam, (LPARAM ) prefix );

							s_allowThisOne = FALSE;
						}
					}

					s_gotNL = FALSE;
				}
			}

			if ( !s_allowThisOne )
				SendToLog( hwnd, g_replaceSel, wParam, lParam, strlen( (char *) lParam ) + 1 );
         break;

		case WM_COPYDATA:
			if ( (HWND) wParam == g_thism59log )
			{
				COPYDATASTRUCT * data = (COPYDATASTRUCT *) lParam;

				if ( data->dwData == g_setChar )
				{
					SendMessage( hwnd, EM_SETSEL, (WPARAM) -1, (LPARAM) -1 );
					SendMessage( hwnd, EM_REPLACESEL,		 0, (LPARAM) data->lpData );
				}
			}
			break;

      default: // Pass other messages to original procedure.
         break;
   }

   // Call original window procedure and return the result to
   // whoever sent this message to the Program Manager.
   return CallWindowProc( g_wpOrigM59Proc, hwnd, uMsg, wParam, lParam );
}

/////////////////////// End Of File ///////////////////////
