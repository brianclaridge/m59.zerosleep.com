/************************************************************
Module name: m59hook.C
Notices: Based on code Copyright (c) 1995 Jeffrey Richter
   Copyright (c) 1997 Ken Nicolson
************************************************************/

#include "..\..\AdvWin32.H"    /* See Appendix B for details. */

#include <windows.h>

#include <stdio.h>
#include <string.h>
#include <richedit.h>

const int RICH_EDIT_ID = 0x3ED;
HWND	m59edit;
HWND	m59log;
LONG	oldProc = 0;
UINT	setChar = 0;
UINT	replaceSel = 0;

/////////////////////////////////////////////////////////////

void SendToLog( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, size_t size )
{
	COPYDATASTRUCT cds = { wParam, size, (void *) lParam };

	if ( SendMessage( m59log, WM_COPYDATA, (WPARAM) hwnd, (LPARAM) &cds ) == FALSE )
		;
}

/////////////////////////////////////////////////////////////

LRESULT CALLBACK subProc(
    HWND hwnd,	// handle of window
    UINT uMsg,	// message identifier
    WPARAM wParam,	// first message parameter
    LPARAM lParam 	// second message parameter
   )
{
	if ( uMsg == EM_SETCHARFORMAT )
		SendToLog( hwnd, setChar, wParam, lParam, sizeof( CHARFORMAT ) );
	else if ( uMsg == EM_REPLACESEL )
		SendToLog( hwnd, replaceSel, wParam, lParam, strlen( (char *) lParam ) + 1 );

	return CallWindowProc( (WNDPROC) oldProc, hwnd, uMsg, wParam, lParam );
}

/////////////////////////////////////////////////////////////

BOOL WINAPI DllMain (HINSTANCE hinstDll, DWORD fdwReason, 
   LPVOID lpvReserved)
{
   if (fdwReason == DLL_PROCESS_ATTACH)
	{
		HWND m59wnd = FindWindow( "Meridian 59", NULL );

		if ( m59wnd != NULL )
		{
			m59edit = GetDlgItem( m59wnd, RICH_EDIT_ID );

			if ( m59edit != NULL )
			{
				setChar = RegisterWindowMessage( "M59HOOK_EM_SETCHARFORMAT" );
				replaceSel = RegisterWindowMessage( "M59HOOK_EM_REPLACESEL" );

				// Anyone at the other end?
				m59log = (HWND) SendMessage( HWND_BROADCAST, setChar, replaceSel, 0 );

				if ( m59log != NULL )
					oldProc = SetWindowLong( m59edit, GWL_WNDPROC, (LONG) subProc );
			}
		}
	}
   else if (fdwReason == DLL_PROCESS_DETACH)
	{
		if ( oldProc )
			SetWindowLong( m59edit, GWL_WNDPROC, (LONG) oldProc );
	}

   return(TRUE);
}


//////////////////////// End Of File ////////////////////////
