// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
private:
	void processSetCharFormat( UINT flags, CHARFORMAT *fmt );
	void processReplaceSel( BOOL canUndo, LPCTSTR str );

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

private:
	BOOL	tryConnectTo( HWND wnd );

protected:
	afx_msg BOOL OnLogStartlogging( void );
	afx_msg BOOL OnLogStoplogging( void );
	BOOL FindM59Window( bool displayDialog );

// Generated message map functions
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTogglelogging();
	afx_msg void OnUpdateTogglelogging(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnViewMidnightatevenhours();
	afx_msg void OnUpdateViewMidnightatevenhours(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnLogRecordtodisk();
	afx_msg void OnUpdateLogRecordtodisk(CCmdUI* pCmdUI);
	afx_msg void OnConfigureAutoconnecttomeridian();
	afx_msg void OnUpdateConfigureAutoconnecttomeridian(CCmdUI* pCmdUI);
	afx_msg void OnViewLoggedmeridian59window();
	afx_msg void OnUpdateViewLoggedmeridian59window(CCmdUI* pCmdUI);
	afx_msg void OnConfigureChatwindow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	UINT	m_setChar;
	UINT	m_replaceSel;

	HWND	m_richEdit;

	BOOL	m_logtodisk;
	BOOL	m_logpurple;

	CFile	m_logfile;
};

/////////////////////////////////////////////////////////////////////////////
