// m59logDoc.cpp : implementation of the CM59logDoc class
//

#include "stdafx.h"
#include "m59log.h"

#include "m59logDoc.h"
#include "m59logView.h"

#include "MessageDlg.h"
#include "YourNameDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const char SYSTEM_MESSAGE[] = "### ";

const char IN_COLD_BLOOD[]			= " has been murdered in cold blood.";
const char INNOCENT_MONSTER[]		= " was just killed by ";
const char FEARED_OUTLAW[]			= "The feared outlaw, ";
const char NOTORIUS_MURDERER[]	= "The notorious murderer, ";

const char MET_JUSTICE_AT[]	= ", has just met justice at ";
const char HAS_BEEN_KILLED[]	= ", has been killed by ";

/////////////////////////////////////////////////////////////////////////////
// CM59logDoc

IMPLEMENT_DYNCREATE(CM59logDoc, CDocument)

BEGIN_MESSAGE_MAP(CM59logDoc, CDocument)
	//{{AFX_MSG_MAP(CM59logDoc)
	ON_COMMAND(ID_CONFIGURE_YOURNAME, OnConfigureYourname)
	ON_COMMAND(ID_VIEW_UNPROCESSEDMESSAGES, OnViewUnprocessedmessages)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CM59logDoc construction/destruction

CM59logDoc::CM59logDoc()
{
	resetAttributes();
}

CM59logDoc::~CM59logDoc()
{
}

void CM59logDoc::resetAttributes()
{
	m_messages.RemoveAll();

	memset( m_totalDeaths, 0, sizeof m_totalDeaths );
	memset( m_eats, 0, sizeof m_eats );
	memset( m_sits, 0, sizeof m_sits );
	memset( m_staff, 0, sizeof m_staff );

	m_tottime = 0;
	m_starttime = 0;

	m_personal.RemoveAll();

	m_broken = 0;

	m_killedwith.RemoveAll();
	m_killedwhat.RemoveAll();

	m_spits = 0;

	m_killedbywhat.RemoveAll();

	memset( &m_tougher, 0, sizeof m_tougher );

	m_area.RemoveAll();

	memset( &m_assassins, 0, sizeof m_assassins );

	m_touch.RemoveAll();

	m_name.Empty();

	m_tokens = 0;

	memset( &m_punch,		0, sizeof m_punch );
	memset( &m_weapons,	0, sizeof m_weapons );
	memset( &m_dodge,		0, sizeof m_dodge );

	m_poisons = 0;
	m_dements = 0;

	m_lastKill = "";

	m_spitons.RemoveAll();
}

BOOL CM59logDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	resetAttributes();

	StopClock();

	UpdateAllViews( NULL, HINT_RESET_CONTENT );

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CM59logDoc serialization

void CM59logDoc::Serialize(CArchive& ar)
{
	char dummyPad = 0;

	if (!ar.IsStoring())
		resetAttributes();

	m_messages.Serialize( ar );

	// As we only ever serialise one thing, we can freely append
	// new things here, without worrying about file compatability
	if (ar.IsStoring())
	{
		ar.Write( m_totalDeaths, sizeof m_totalDeaths );
		ar.Write( m_eats, sizeof m_eats );
		ar.Write( m_sits, sizeof m_sits );
		ar.Write( m_staff, sizeof m_staff );
		ar << ClockTick();

		m_personal.Serialize( ar );
		
		ar << m_broken;

		m_killedwith.Serialize( ar );
		m_killedwhat.Serialize( ar );

		ar << m_spits;

		m_killedbywhat.Serialize( ar );

		ar.Write( &m_tougher, sizeof m_tougher );

		ar << m_name;

		m_area.Serialize( ar );

		ar.Write( &m_assassins, sizeof m_assassins );

		m_touch.Serialize( ar );

		ar << m_tokens;

		ar.Write( &m_punch,		sizeof m_punch );
		ar.Write( &m_weapons,	sizeof m_weapons );
		ar.Write( &m_dodge,		sizeof m_dodge );

		ar.Write( &m_poisons,	sizeof m_poisons );
		ar.Write( &m_dements,	sizeof m_dements );

		// Dud byte - serialize will fail without it
		ar.Write( &dummyPad,		sizeof dummyPad );
		m_spitons.Serialize( ar );
	}
	else
	{
		ar.Read( m_totalDeaths,	sizeof m_totalDeaths );
		ar.Read( m_eats,			sizeof m_eats );
		ar.Read( m_sits,			sizeof m_sits );
		ar.Read( m_staff,			sizeof m_staff );

		ar >> m_tottime;

		m_personal.Serialize( ar );

		ar >> m_broken;

		m_killedwith.Serialize( ar );
		m_killedwhat.Serialize( ar );

		ar >> m_spits;

		m_killedbywhat.Serialize( ar );

		ar.Read( &m_tougher, sizeof m_tougher );

		ar >> m_name;

		m_area.Serialize( ar );

		ar.Read( &m_assassins, sizeof m_assassins );

		m_touch.Serialize( ar );

		ar >> m_tokens;

		ar.Read( &m_punch,	sizeof m_punch );
		ar.Read( &m_weapons,	sizeof m_weapons );
		ar.Read( &m_dodge,	sizeof m_dodge );

		if (  ar.Read( &m_poisons, sizeof m_poisons ) &&
				ar.Read( &m_dements, sizeof m_dements ) &&
				ar.Read( &dummyPad,  sizeof dummyPad ) )
		{
			m_spitons.Serialize( ar );
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CM59logDoc diagnostics

#ifdef _DEBUG
void CM59logDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CM59logDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CM59logDoc commands

void CM59logDoc::AddString( LPCTSTR str, int num )
{
	if ( *str )
	{
		SetModifiedFlag();

		int count;
		CString string( str );

		if ( m_messages.Lookup( string, count ) )
			count += num;
		else
			count = num;

		UINT msgType;

		if ( processMessage( string, count, msgType ) )
		{
			m_messages.RemoveKey( string );

			UpdateAllViews( NULL, msgType );
		}
		else
			m_messages[ string ] = count;
	}
}

BOOL CM59logDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// Document opened, m_messages set up
	POSITION pos = m_messages.GetStartPosition();
	int count;
	UINT	msgType;
	CString string;

	while ( pos )
	{
		m_messages.GetNextAssoc( pos, string, count );

		if ( processMessage( string, count, msgType ) )
			m_messages.RemoveKey( string );
	}

	UpdateAllViews( NULL, HINT_RESET_CONTENT );

	if ( m_name.IsEmpty() )
		OnConfigureYourname();

	return TRUE;
}

BOOL CM59logDoc::processMessage( const CString &str, int count, UINT &msgType )
{
	BOOL processed = FALSE;

	msgType = 0;

	if ( processDeathNotices( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_DEATH;
	}

	if ( processPersonalEffects( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_PESPELL;
	}

	if ( processAreaSpells( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_AREASPELL;
	}

	if ( processTouchSpells( str, count ) )
	{
		processed = TRUE;
		msgType |= (MSG_TOUCHSPELL | MSG_KILLED);
	}

	if ( processFood( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_FOOD;
	}

	if ( processStaff( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_STAFF;
	}

	if ( processSits( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_SITS;
	}

	if ( processBreaks( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_BREAK;
	}

	if ( processKilled( str, count ) )
	{
		processed = TRUE;
		msgType |= (MSG_KILLED | MSG_WEAPONS | MSG_TOUGHER);
	}

	if ( processWeapons( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_WEAPONS;
	}

	if ( processSpits( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_KILLED;
	}

	if ( processKilledBy( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_KILLEDBY;
	}

	if ( processAssassins( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_ASSASSINS;
	}

	if ( processTougher( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_TOUGHER;
	}

	if ( processTokens( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_TOKEN;
	}

	if ( processSicks( str, count ) )
	{
		processed = TRUE;
		msgType |= MSG_SICKS;
	}

	if ( !processed && ( !str.Compare( "!" ) || processIgnores( str, count ) ) )
		processed = TRUE;

	return processed;
}

const char *Eats[] =
{
	"Yum-yum good!",
	"Refreshing to sip, ",
	"You are too full to eat",
	""
};

BOOL CM59logDoc::processFood( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Eats, &index ) )
	{
		m_eats[ index ] += count;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Staff[] =
{
	" looks startled as ",
	" taps the gnarled staff ",
	" tap the staff on the ",
	""
};

BOOL CM59logDoc::processStaff( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Staff, &index ) )
	{
		m_staff[ index ] += count;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Spit[] =
{
	"You spit on the corpse of your unworthy foe.",
	""
};

BOOL CM59logDoc::processSpits( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Spit, &index ) )
	{
		m_spits += count;

		if ( m_lastKill.GetLength() > 0 )
		{
			// Count what we've spat on
			int oldCount;

			if ( !m_spitons.Lookup( m_lastKill, oldCount ) )
				oldCount = 0;

			m_spitons[ m_lastKill ] = oldCount + count;
		}

		return TRUE;
	}
	else
		return FALSE;
}

const char *Improve[] =
{
	"You have improved in the art of ",
	""
};

const char *Weaponcraft[] =
{
	"axe wielding",
	"fencing",
	"hammer wielding",
	"mace fighting",
	"scimitar wielding",
	"slash",
	""
};

const char *Punch[] =
{
	"brawling",
	"punch",
	""
};

const char *Dodge[] =
{
	"dodge",
	"parry",
	""
};

BOOL CM59logDoc::processWeapons( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Improve, &index ) )
	{
		if ( FindInTable( str, Weaponcraft ) )
		{
			m_weapons.improves += count;
			m_weapons.sinceprev = m_weapons.sincelast;
			m_weapons.sincelast = 0;
		}
		else if ( FindInTable( str, Punch ) )
		{
			m_punch.improves += count;
			m_punch.sinceprev = m_punch.sincelast;
			m_punch.sincelast = 0;
		}
		else if ( FindInTable( str, Dodge ) )
		{
			m_dodge.improves += count;
			m_dodge.sinceprev = m_dodge.sincelast;
			m_dodge.sincelast = 0;
		}
		else
			return FALSE;

		return TRUE;
	}

	return FALSE;
}

const char *PersonalEffectSpells[] =
{
	"unholy weapon",
	"unholy resolve",
	"holy resolve",
	"resist cold",
	"rescue",
	"create food",
	"holy weapon",
	"shadow form",
	"fade",
	"invisibility",
	"Kara'hol's curse",
	"mana focus",
	"withstand fire",
	"blink",
	"create mace",
	"super strength",
	"bless",
	"enchant weapon",
	"magic shield",
	"night vision",
	"resist shock",
	"mend",
	"resist magic",
	"mana bomb",
	"armor of Gort",
	""
};

const char *PersonalEffectSuccess[] =
{
	" is now dedicated to Qor.",
	"The spirit of Qor enters your body, ",
	"You feel a warm presence fortifying your defense against evil.",
	"The magical fire of Faren enters your body.",
	"You have been sent to a safe place.",
	"An apple appears.",
	" is now dedicated to Shal'ille.",
	"You melt into your shadow.",
	"Your physical form fades from existence leaving only a shimmering ",
	"A shimmering field cloaks your body.",
	"upon you making your blood boil ",
 	"You feel your newly focused mana ",
	"Cool magical energy pulses through ",
	"You focus your whole will on casting blink",
	"A mace appears",
	"Your blood tingles with the force of Kraanan",
	"Kraanan fills you with the spirit of battle",
	"Your mace is now dedicated to Kraanan",
	"A protective shield of magical energy forms around you",
	"Your eyes burn with magical energy",
	"Kraanan fortifies you against shock attacks",
	"bind themselves together to form a new whole",
	"Kraanan fortifies you against magic attacks",
	"All of your mana burns away",
	"feels taut as the Armor of Gort forms",
	""
};

const char *SpellFailImprove[] =
{
	"You were unsuccessful in casting ",
	"You have improved in the art of ",
	""
};

BOOL CM59logDoc::processPersonalEffects( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, PersonalEffectSuccess, &index ) )
	{
		spellPerformance &spell = m_personal[ PersonalEffectSpells[ index ] ];

		spell.successes += count;
		spell.sincelast += count;

		return TRUE;
	}
	else
	{
		if ( FindInTable( str, SpellFailImprove, &index ) )
		{
			int spellIndex;

			if ( FindPESpellIndex( str, &spellIndex ) )
			{
				spellPerformance &spell = m_personal[ PersonalEffectSpells[ spellIndex ] ];
				if ( index == 0 )
				{
					// More failures
					spell.fails += count;
				}
				else
				{
					// Improved - move average along
					spell.sinceprev = spell.sincelast;
					spell.sincelast = 0;
					spell.improves += count;
				}

				return TRUE;
			}
		}
	}

	return FALSE;
}

BOOL FindPESpellIndex( LPCSTR message, int *index )
{
	return FindInTable( message, PersonalEffectSpells, index );
}

const char *AreaSpells[] =
{
	"darkness",
	"forces of light",
	"light",
	"truce",
	"umbrella",
	"winds",
	"heat",
	"earthquake",
	"discordance",
	"killing fields",
	"anti-magic aura",
	"sandstorm",
	""
};

const char *AreaSuccess[] =
{
	"A curtain of darkness is drawn across the room,",
	"This place is infused with the spirit of Shal'ille",
	"A magical glow suffuses through the area.",
	"A numbing calm settles upon your mind, ",
	"A mystic, shimmering dome of light emerges ",
	"Violent winds suddenly sweep the area ",
	"Faren earth magic fills the room, ",
	"You raise your arms to the sky and invoke the fury of Faren!",
	"The fabric of space twists subtly,",
	"Kraanan smiles and battle fury fills your heart.",
	"The mana field begins to fluctuate.",
	"From out of nowhere, swirling dust begins to needle into your skin",
	""
};

BOOL CM59logDoc::processAreaSpells( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, AreaSuccess, &index ) )
	{
		spellPerformance &spell = m_area[ AreaSpells[ index ] ];

		spell.successes += count;
		spell.sincelast += count;

		return TRUE;
	}
	else
	{
		if ( FindInTable( str, SpellFailImprove, &index ) )
		{
			int spellIndex;

			if ( FindAreaSpellIndex( str, &spellIndex ) )
			{
				// Filter out other people casting umbrella
				if ( strcmp( AreaSpells[ spellIndex ], "umbrella" ) ||
						strstr( str, m_name ) )
				{
					spellPerformance &spell = m_area[ AreaSpells[ spellIndex ] ];
					if ( index == 0 )
					{
						// More failures
						spell.fails += count;
					}
					else
					{
						// Improved - move average along
						spell.sinceprev = spell.sincelast;
						spell.sincelast = 0;
						spell.improves += count;
					}
				}

				return TRUE;
			}
		}
	}

	return FALSE;
}

BOOL FindAreaSpellIndex( LPCSTR message, int *index )
{
	return FindInTable( message, AreaSpells, index );
}

const char *TouchSpells[] =
{
	"touch of flame",
	"holy touch",
	"holy touch", // two success messages
	"zap",
	"cure disease",
	"cure poison",
	"hospice",
	"major heal",
	"minor heal",
	"mark of dishonor",
	"purify",
	"purify",  // two success messages
	"remove curse",
	"remove curse",  // two success messages
	"blind",
	"hold",
	"enfeeble",
	"vampiric touch",
	"icy fingers",
	"acid touch",
	"swap",
	"defile",
	"fireball",
	"dement",
	"brittle",
	"lightning bolt",
	"shatter",
	""
};

const char *TouchSuccess[] =
{
	", engulfed in flames, lets out a final scream.",
	" finally succumbs, finding peace ",
	"You lay your hands on ",
	" lets out a final scream in protest ",
	"You cast cure disease ",
	"You cast cure poison ",
	"The spirit of Shal'ille enters your body ",
	"You are amazed to see your wounds close up",
	"You are amazed to see your wounds close up",  // Damn! major & minor both have the same text
	"The eyes of Shal'ille turn towards ",
	"You cast purify on ",
	"Your soul has been cleansed of ",
	"Shal'ille tears the cursed item ",
	"You cast remove curse on ",
	" is now blind.",
	" is now held in place by a magical force.",
	"You sense an unsavory presence.",
	" withers before your touch, and is no more.",
	" finds a cold unsurpassed by any other",
	" screams and melts into an unobtrusive puddle.",
	" is yanked away to be replaced by ",
	"Your nausea betokens the imminence of Qor.",
	"A ball of fire strikes ",
	"You sense an unsavoury presence",
	"You focus your eyes intensely on ",
	"Lightning strikes ",
	"You shatter ",
	""
};

BOOL CM59logDoc::processTouchSpells( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, TouchSuccess, &index ) )
	{
		spellPerformance &spell = m_touch[ TouchSpells[ index ] ];

		spell.successes += count;
		spell.sincelast += count;

		return TRUE;
	}
	else
	{
		if ( FindInTable( str, SpellFailImprove, &index ) )
		{
			int spellIndex;

			if ( FindTouchSpellIndex( str, &spellIndex ) )
			{
				spellPerformance &spell = m_touch[ TouchSpells[ spellIndex ] ];
				if ( index == 0 )
				{
					// More failures
					spell.fails += count;
				}
				else
				{
					// Improved - move average along
					spell.sinceprev = spell.sincelast;
					spell.sincelast = 0;
					spell.improves += count;
				}

				return TRUE;
			}
		}
	}

	return FALSE;
}

BOOL FindTouchSpellIndex( LPCSTR message, int *index )
{
	return FindInTable( message, TouchSpells, index );
}

const char *IgnoreSorted[] =
{
	"###",
	"A guardian angel whispers ",
	"A voice whispers, ",
	"After putting on the ring ",
	"All hail ",
	"As you pick the item up, you feel ",
	"As you put the amulet on,",
	"Be it known that ",
	"Combat is already impossible here.",
	"Faren earth magic fills the room ",
	"Flames erupt from ",
	"Flames leap from your fingers and burn ",
	"Hail your guildmate ",
	"Heavenly voices sing as ",
	"Hey!  You almost hit ",
	"I am sorry, but my current ",
	"If you followed Princess Kat",
	"It would be foolish to waste the ",
	"Loss of concentration ",
	"Magical winds are already present.",
	"Members of the ",
	"No one else from your ",
	"No one with that name ",
	"Only those in guilds may",
	"Please welcome the newest member ",
	"Sending mail.",
	"Suddenly weak, your eyes roll ",
	"System is saving; please wait",
	"System save completed; resume play",
	"Techinques learned from visitors ",
	"The armor-heating",
	"The battle fury from the Berserker",
	"The calm that had gripped ",
	"The curtain of darkness ",
	"The earth convulses beneath your feet,",
	"The fullness of your mental capacities ",
	"The light spell wears off",
	"The magical hold lifts and ",
	"The magical wand had no ",
	"The mana field is fluctuating here.",
	"The mana field returns to normal.",
	"The pain seems to resonate and grow ",
	"The poison abates somewhat.",
	"The power of Shal'ille burns all ",
	"The ring pops off of ",
	"The shimmering field around you dissolves,",
	"The spirit of Kraanan departs ",
	"The spirit of Kraanan has left you.",
	"The spirit of Shal'ille departs ",
	"The spirit of Shal'ille has left you.",
	"The token is very heavy, ",
	"The wand pulses once in your hand.",
	"The winds slow and then cease.",
	"There is no group matching that name.",
	"There is no spell with that name.",
	"There's no one nearby ",
	"This area is already lit.",
	"This door is locked.",
	"This place is already ",
	"This place is illuminated by a magical glow",
	"This place is under a darkness enchantment.",
	"To your surprise, much of the pain",
	"Today marks the forging of an alliance ",
	"Under suspicion of ",
	"Violent winds sweep the area and ",
	"Waving your hand past the cold brazier,",
	"Welcome to the world ",
	"What?  (Press F1 ",
	"You already have ",
	"You are already using that.",
	"You are becoming exhausted ",
	"You are encompassed by a dome ",
	"You are filled with the spirit ",
	"You are not even holding ",
	"You are relieved to feel ",
	"You are too tired ",
	"You are unable to ",
	"You are using too many ",
	"You cackle with glee as the ",
	"You can feel your ",
	"You can move again.",
	"You can't attack the ",
	"You can't broadcast a",
	"You can't cast ",
	"You can't fight here.",
	"You can't offer to ",
	"You can't pick up ",
	"You can't reach ",
	"You can't send this",
	"You can't take the ",
	"You can't use ",
	"You cannot cast this ",
	"You demote ",
	"You disband the ",
	"You don't have enough mana to ",
	"You don't have that amount of ",
	"You don't have the reagents to ",
	"You extend to ",
	"You fade back to your own colors.",
	"You feel a wave of vertigo.",
	"You feel better",
	"You feel chilled as the ",
	"You feel drained and out of breath ",
	"You feel giddy with energy as ",
	"You feel the ring working.",
	"You focus your whole will on ",
	"You have a funny feeling that attacking ",
	"You have a trade offer ",
	"You have been sent to ",
	"You have lost your ",
	"You have new mail from ",
	"You have no groups defined",
	"You have these groups defined",
	"You have this urge to go ",
	"You hear a voice whisper",
	"You hear whispered rumors ",
	"You hop through a hole ",
	"You ladle a steamy ",
	"You learn that your liege's ",
	"You lose your concentration ",
	"You may not join a new guild ",
	"You must be wielding",
	"You must specify",
	"You narrowly dodge ",
	"You no longer have",
	"You offer a yelp of pain ",
	"You open the door and ",
	"You pledge your support ",
	"You point.",
	"You promote ",
	"You realize too late that ",
	"You sense a shift in the balance ",
	"You sense that no one hears ",
	"You stumble down the hole at ",
	"You try to wield the dark blade, ",
	"You watch with satisfaction as a ",
	"You wave your hand",
	"You're already resting.",
	"You're not resting.",
	"You're unable to pick up ",
	"Your association with the Duke ",
	"Your blood boils with lust ",
	"Your body cools noticeably as ",
	"Your body freezes as total exhaustion ",
	"Your body warms noticeably as ",
	"Your dagger gains ",
	"Your guildmate ",
	"Your hands are too full ",
	"Your honorable ally,",
	"Your liege is no ",
	"Your nerves jangle",
	"Your physical form is visible ",
	"Your physical form shimmers and ",
	"Your punch misses ",
	"Your slash misses ",
	"Your slash penetrates ",
	"Your soul twitches as you interfere ",
	"Your touch of flame misses "
};

const char *Ignores[] =
{
	"and invokes the fury of Faren",
	"eyes focus intensely on ",
	"invitation ",
	"pledges to support",
	"has promoted ",
	"has demoted ",
	"and points a finger at ",
	"grins as a jolt of electricity ",
	"touches you, freezing your flesh",
	"lets out a cry of pain",
	"is now held in place ",
	"...dodge all they want",
	"...the key to making mischief",
	"...the master of the storm",
	"...the vile's aim",
	"names to group.",
	"= logged on):",
	"pauses briefly to lick its wounds ",
	"hits you with a jolt of purity.",
	"hits you, and you feel your soul has been invaded.",
	"slashes your side, ",
	"is too far away to hit ",
	"misses you.",
	"and makes a mystical gesture.",
	"of new mail.",
	"lays hands on you, and you feel ",
	" You fall through a hole ",
	"with a hard right cross.",
	"frost, tremble, and shatter!",
	"narrowly dodges your ",
	"grins and shrugs off your attack.",
	"staggers backwards from the blow.",
	"name is ambiguous.",
	"is busy right now with ",
	"mana violently detonates!",
	"has valiantly slain the ",
	"is out of range.",
	"...calm only prevails if",
	"is perfectly healthy.",
	"fire flares brightly, ",
	"is not suffering from poison.",
	"black dagger",
	"canceled the offer.",
	"renounces all ties ",
	"is ignoring messages from you.",
	""
};

int compare( const void *arg1, const void *arg2 )
{
	const char *str1 = ((const char *) arg1);
	const char *str2 = *((const char **) arg2);

	while ( *str1 && *str2 )
	{
		if ( *str1 > *str2 )
			return 1;
		else if ( *str1 < *str2 )
			return -1;

		str1++;
		str2++;
	}

	// We got to the end - good enough for me!
	return 0;
}

BOOL CM59logDoc::processIgnores( const CString &str, int count )
{
	if ( bsearch( (LPCTSTR) str, IgnoreSorted, sizeof IgnoreSorted / sizeof IgnoreSorted[0], sizeof (char *), compare ) )
		return TRUE;
	else
		return FindInTable( str, Ignores );
}

const char *Sits[] =
{
	"You rest.",
	"You stop resting.",
	""
};

BOOL CM59logDoc::processSits( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Sits, &index ) )
	{
		m_sits[ index ] += count;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Assassins[] =
{
	"You have been slain at the hands ",
	"You have slain ",
	""
};

BOOL CM59logDoc::processAssassins( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Assassins, &index ) )
	{
		m_assassins[ index ] += count;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Tougher[] =
{
	"You suddenly feel a little tougher.",
	""
};

BOOL CM59logDoc::processTougher( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Tougher, &index ) )
	{
		m_tougher.improves += count;
		m_tougher.sinceprev = m_tougher.sincelast;
		m_tougher.sincelast = 0;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Breaks[] =
{
	" falls to pieces",
	" shatters into pieces",
	" are a tangled mess of metal.",
	", simply disappears!",
	""
};

BOOL CM59logDoc::processBreaks( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Breaks, &index ) )
	{
		m_broken += count;

		return TRUE;
	}
	else
		return FALSE;
}

const char *Tokens[] =
{
	"You are astonished to see a ",
	""
};

BOOL CM59logDoc::processTokens( const CString &str, int count )
{
	int index;

	if ( FindInTable( str, Tokens, &index ) )
	{
		m_tokens += count;

		return TRUE;
	}
	else
		return FALSE;
}

BOOL CM59logDoc::processSicks( const CString &str, int count )
{
	if ( strstr( str, "Fresh poison courses through " ) )
	{
		m_poisons += count;

		return TRUE;
	}
	else if ( strstr( str, "Somehow you feel less sharp " ) )
	{
		m_dements += count;

		return TRUE;
	}
	else
		return FALSE;
}

BOOL CM59logDoc::processDeathNotices( const CString &str, int count )
{
	BOOL	processed;

	if ( !strncmp( str, SYSTEM_MESSAGE, sizeof( SYSTEM_MESSAGE ) - 1 ) )
	{
		processed = TRUE;

		if ( strstr( str, IN_COLD_BLOOD ) )
			m_totalDeaths[ WHITE_PLAYER ][ PKED ] += count;
		else if ( strstr( str, INNOCENT_MONSTER ) )
			m_totalDeaths[ WHITE_PLAYER ][ MONSTER ] += count;
		else if ( strstr( str, FEARED_OUTLAW ) )
		{
			if ( isMonsterAfter( str, MET_JUSTICE_AT ) )
				m_totalDeaths[ ORANGE_PLAYER ][ MONSTER ] += count;
			else
				m_totalDeaths[ ORANGE_PLAYER ][ PKED ] += count;
		}
		else if ( strstr( str, NOTORIUS_MURDERER ) )
		{
			if ( isMonsterAfter( str, HAS_BEEN_KILLED ) )
				m_totalDeaths[ RED_PLAYER ][ MONSTER ] += count;
			else
				m_totalDeaths[ RED_PLAYER ][ PKED ] += count;
		}
		else
			processed = FALSE;
	}
	else
		processed = FALSE;

	return processed;
}

BOOL CM59logDoc::isMonsterAfter( const CString &str, LPCSTR message )
{
	LPCSTR msg;

	if ( ( msg = strstr( str, message ) ) != NULL )
	{
		msg += strlen( message );

		return isAMonster( msg );
	}
	else
	{
		// Should maybe have a third state for a total fail?
		TRACE( "Message not found at all in isMonsterAfter( %s, %s )\n", (LPCTSTR) str, message );
		return FALSE;
	}
}

const char *Monsters[] =
{
	" mutant ant",
	" ant",
	" baby spider",
	" centipede",
	" fey dirhai",
	" fey elhai",
	" fungus beast",
	" ghost of Far'Nohl",
	" giant rat",
	" giant scorpion",
	" living tree",
	" lupogg",
	" mummy",
	" orc",
	" queen spider",
	" revenant",
	" shadow mummy",
	" skeleton",
	" slime",
	" spider",
	" troll",
	" yeti",
	" zombie",
	" token death",
	""
};

BOOL CM59logDoc::isAMonster( LPCSTR message )
{
	return FindInTable( message, Monsters );
}

const char *DeathMethods[] =
{
	" crumples to the ground, ",
	"You killed ",
	", engulfed in flames, lets out a final scream.",
	" finally succumbs, finding peace ",
	" lets out a final scream in protest ",
	" withers before your touch, and is no more.",
	" finds a cold unsurpassed by any other",
	" screams and melts into an unobtrusive puddle.",
	""
};

const char *MethodName[] =
{
	"Punch",
	"Weaponcraft",
	"Touch of Flame",
	"Holy Touch",
	"Zap",
	"Vampiric Touch",
	"Icy Fingers",
	"Acid Touch",
	""
};

BOOL CM59logDoc::processKilled( const CString &str, int count )
{
	int methodIndex;

	if ( FindInTable( str, DeathMethods, &methodIndex ) )
	{
		m_killedwith[ MethodName[ methodIndex ] ] += count;

		if ( !strcmp( MethodName[ methodIndex ], "Punch" ) )
		{
			m_punch.sincelast += count;
			m_punch.kills += count;
		}
		else if ( !strcmp( MethodName[ methodIndex ], "Weaponcraft" ) )
		{
			m_weapons.sincelast += count;
			m_weapons.kills += count;
		}

		int monsterIndex;

		if ( FindMonsterIndex( str, &monsterIndex ) )
		{
			m_killedwhat[ Monsters[ monsterIndex ] + 1 ] += count;
			m_lastKill = Monsters[ monsterIndex ];
		}
		else
		{
			m_killedwhat[ "players" ] += count;
			m_lastKill = "players";
		}

		m_tougher.sincelast += count;
		m_tougher.kills += count;

		m_dodge.sincelast += count;
		m_dodge.kills += count;

		return TRUE;
	}

	return FALSE;
}

BOOL FindKilledWithIndex( LPCSTR message, int *index )
{
	return FindInTable( message, MethodName, index );
}

// These next two are identical
BOOL FindKilledByIndex( LPCSTR message, int *index )
{
	return FindInTable( message, Monsters, index );
}

BOOL FindMonsterIndex( LPCSTR message, int *index )
{
	return FindInTable( message, Monsters, index );
}

const char *KilledBy[] =
{
	"You are dead, poor soul.  Go now, ",
	""
};

BOOL CM59logDoc::processKilledBy( const CString &str, int count )
{
	int methodIndex;

	if ( FindInTable( str, KilledBy, &methodIndex ) )
	{
		int monsterIndex;

		if ( FindInTable( str, Monsters, &monsterIndex ) )
		{
			m_killedbywhat[ Monsters[ monsterIndex ] + 1 ] += count;
		}
		else
		{
			m_killedbywhat[ "players" ] += count;
		}

		return TRUE;
	}
	else if ( strstr( str, "As you die, the token pulsates" ) )
	{
		m_killedbywhat[ "token death" ] += count;

		return TRUE;
	}

	return FALSE;
}

#define index(c) ((c)-' ')

const int d = 32;
const int q = 33554393;

int dMVal( int val )
{
	const int MAXDM = 100;
	static int dMArray[ MAXDM ] = { 1, 1 };
	static bool firsttime = true;

	if ( firsttime )
	{
		for ( int i = 2; i < MAXDM; i++ )
			dMArray[ i ] = ( dMArray[ i - 1 ] * d ) % q;

		firsttime = false;
	}

	if ( val >= MAXDM )
		AfxMessageBox( "Oops, val is too large!" );

	return dMArray[ val ];
}

/*
const char *mystrstr( const char *source, const char *find )
{
//return strstr( source, find );
	int dM;
	int i, h1 = 0, h2 = 0;
	int M = strlen( find ), N = strlen( source );
	if ( M > N )
		return NULL;

	dM = dMVal( M );

	for ( i = 0; i < M; i++ )
	{
		h1 = (h1*d+index(find[i])) % q;
		h2 = (h2*d+index(source[i])) % q;
	}
	for ( i = 0; h1 != h2; i++ )
	{
		if( i > N-M )
			return NULL;

		h2 = (h2+d*q-index(source[i])*dM) % q;
		h2 = (h2*d+index(source[i+M])) % q;
	}

	return source + i;
}

char skip[256];

void initskip( const char *str, int len )
{
	if ( len > 256 )
		AfxMessageBox( "Oops, len is too long!" );

	memset( skip, len, sizeof skip );

	while ( *str )
	{
		skip[ index( *str ) ] = --len;

		str++;
	}
}

const char *my2ndstrstr( const char *source, const char *find )
{
//return strstr( source, find );
	int i, j, t, M = strlen( find ), N = strlen( source );

	if ( M > N )
		return NULL;
	initskip( find, M );
	for ( i = M-1, j = M-1; j > 0; i--, j-- )
		while ( source[i] != find[j] )
		{
			t = skip[ index( source[i] ) ];
			i += (M-j > t) ? M-j : t;

			if ( i >= N )
				return NULL;

			j = M-1;
		}

	return source + i;
}
*/
BOOL FindInTable(	LPCSTR message,
						const char *table[],
						int *index /* = NULL */ )
{
	BOOL	found = FALSE;

	for ( int count = 0; !found && table[ count ][ 0 ]; count++ )
		if ( strstr( message, table[ count ] ) )
			found = TRUE;

	if ( index )
		*index = found ? (count - 1) : -1;

	return found;
}

void CM59logDoc::OnConfigureYourname() 
{
	CYourNameDlg dlg;

	dlg.m_name = GetName();

	if ( dlg.DoModal() == IDOK )
		SetName( dlg.m_name );
}

void CM59logDoc::OnViewUnprocessedmessages() 
{
	CMessageDlg dlg;

	dlg.m_doc = this;

	dlg.DoModal();
}

BOOL CM59logDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	if ( m_name.IsEmpty() )
		OnConfigureYourname();
	
	return CDocument::OnSaveDocument(lpszPathName);
}
