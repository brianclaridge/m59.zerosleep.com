// YourNameDlg.cpp : implementation file
//

#include "stdafx.h"
#include "m59log.h"
#include "YourNameDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CYourNameDlg dialog


CYourNameDlg::CYourNameDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CYourNameDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CYourNameDlg)
	m_name = _T("");
	//}}AFX_DATA_INIT
}


void CYourNameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CYourNameDlg)
	DDX_Text(pDX, IDC_YOURNAME, m_name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CYourNameDlg, CDialog)
	//{{AFX_MSG_MAP(CYourNameDlg)
	ON_EN_CHANGE(IDC_YOURNAME, OnChangeYourname)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CYourNameDlg message handlers

void CYourNameDlg::OnChangeYourname() 
{
	// OK only if text in box
	::EnableWindow(	GetDlgItem( IDOK )->GetSafeHwnd(),
							GetDlgItem( IDC_YOURNAME )->GetWindowTextLength() );
}

BOOL CYourNameDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// OK only if text in box
	::EnableWindow(	GetDlgItem( IDOK )->GetSafeHwnd(),
							GetDlgItem( IDC_YOURNAME )->GetWindowTextLength() );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
