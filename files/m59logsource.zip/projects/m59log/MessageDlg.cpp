// MessageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "m59log.h"
#include "MessageDlg.h"

#include "m59logDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMessageDlg dialog


CMessageDlg::CMessageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMessageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMessageDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMessageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMessageDlg)
	DDX_Control(pDX, IDC_MESSAGES, m_messages);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMessageDlg, CDialog)
	//{{AFX_MSG_MAP(CMessageDlg)
	ON_BN_CLICKED(IDC_SELECTALL, OnSelectall)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMessageDlg message handlers

BOOL CMessageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_changemade = FALSE;

	int				count;
	CString			string;
	CString			fmt;

	const MESSAGES &msgs = m_doc->GetMessages();

	POSITION pos = msgs.GetStartPosition();

	while ( pos )
	{
		msgs.GetNextAssoc( pos, string, count );

		fmt.Format( "%s\t%d", string, count );

		m_messages.AddString( fmt );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMessageDlg::OnSelectall() 
{
	m_messages.SelItemRange( TRUE, 0, m_messages.GetCount() - 1 );	
}

void CMessageDlg::OnDelete() 
{
	int selCount = m_messages.GetSelCount();

	if ( selCount > 0 )
	{
		int *items = new int[ selCount ];

		m_messages.GetSelItems( selCount, items );

		while ( --selCount >= 0 )
			m_messages.DeleteString( items[ selCount ] );

		delete [] items;

		m_changemade = true;
	}
}

void CMessageDlg::OnOK() 
{
	if ( m_changemade )
	{
		m_doc->ResetAllMessages();
		
		int selCount = m_messages.GetCount();

		CString text, msg;
		char *tabpos;

		while ( --selCount >= 0 )
		{
			m_messages.GetText( selCount, text );

			if ( ( tabpos = strchr( text, '\t' ) ) != NULL )
			{
				msg = text.Left( tabpos - text );
				m_doc->AddString( msg, atoi( tabpos + 1 ) );
			}
		}
	}

	CDialog::OnOK();
}
