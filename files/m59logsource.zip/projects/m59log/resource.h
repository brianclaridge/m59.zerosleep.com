//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by m59log.rc
//
#define IDSHOWWINDOW                    3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_M59LOGTYPE                  129
#define IDD_YOURNAME                    130
#define IDD_MESSAGES                    131
#define IDD_CHOOSEWINDOW                135
#define IDD_CHATWINDOW                  136
#define IDC_MAILME                      1000
#define IDC_VISITME                     1001
#define IDC_YOURNAME                    1001
#define ID_INDICATOR_TIMEON             1002
#define IDC_VISIT3DO                    1002
#define IDC_DELETE                      1002
#define ID_INDICATOR_MERTIME            1003
#define IDC_SELECTALL                   1003
#define IDC_MESSAGES                    1004
#define ID_INDICATOR_THISTIMEON         1004
#define IDC_WINDOWTITLELIST             1005
#define IDC_COLORCHANGES                1006
#define IDC_TELLCOLOR                   1007
#define IDC_TELLSTATIC                  1009
#define IDC_TELLBOLD                    1011
#define IDC_TELLITALIC                  1012
#define IDC_TELLPREFIX                  1013
#define IDC_SENDCOLOR                   1014
#define IDC_SENDSTATIC                  1015
#define IDC_SENDBOLD                    1016
#define IDC_SENDITALIC                  1017
#define IDC_SENDPREFIX                  1018
#define ID_LOG_STARTLOGGING             32771
#define ID_LOG_STOPLOGGING              32772
#define ID_CONFIGURE_CHOOSEFONT         32774
#define ID_TOGGLELOGGING                32775
#define ID_VIEW_MIDNIGHTATEVENHOURS     32776
#define ID_LOG_RECORDTODISK             32777
#define ID_CONFIGURE_YOURNAME           32779
#define ID_VIEW_UNPROCESSEDMESSAGES     32780
#define ID_CONFIGURE_AUTOCONNECTTOMERIDIAN 32781
#define ID_VIEW_LOGGEDMERIDIAN59WINDOW  32782
#define ID_EDIT_COPYALLSUBTREE          32784
#define ID_EDIT_COPYCOMPLETETREE        32785
#define ID_CONFIGURE_CHATWINDOW         32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
