// ChatWindow.cpp : implementation file
//

#include "stdafx.h"
#include "m59log.h"
#include "ChatWindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChatWindow dialog


CChatWindow::CChatWindow(CWnd* pParent /*=NULL*/)
	: CDialog(CChatWindow::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChatWindow)
	m_colorchanges = FALSE;
	m_sendbold = FALSE;
	m_senditalic = FALSE;
	m_sendprefix = _T("");
	m_tellbold = FALSE;
	m_tellitalic = FALSE;
	m_tellprefix = _T("");
	//}}AFX_DATA_INIT

	m_sendColor = RGB( 255, 255, 255 );
	m_tellColor = RGB( 255, 255, 255 );

	m_sendFont = NULL;
	m_tellFont = NULL;
}

void CChatWindow::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChatWindow)
	DDX_Control(pDX, IDC_TELLSTATIC, m_tell);
	DDX_Control(pDX, IDC_SENDSTATIC, m_send);
	DDX_Check(pDX, IDC_COLORCHANGES, m_colorchanges);
	DDX_Check(pDX, IDC_SENDBOLD, m_sendbold);
	DDX_Check(pDX, IDC_SENDITALIC, m_senditalic);
	DDX_Text(pDX, IDC_SENDPREFIX, m_sendprefix);
	DDV_MaxChars(pDX, m_sendprefix, 4);
	DDX_Check(pDX, IDC_TELLBOLD, m_tellbold);
	DDX_Check(pDX, IDC_TELLITALIC, m_tellitalic);
	DDX_Text(pDX, IDC_TELLPREFIX, m_tellprefix);
	DDV_MaxChars(pDX, m_tellprefix, 4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChatWindow, CDialog)
	//{{AFX_MSG_MAP(CChatWindow)
	ON_BN_CLICKED(IDC_TELLCOLOR, OnTellcolor)
	ON_BN_CLICKED(IDC_SENDCOLOR, OnSendcolor)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_SENDBOLD, OnSendbold)
	ON_BN_CLICKED(IDC_SENDITALIC, OnSenditalic)
	ON_BN_CLICKED(IDC_TELLBOLD, OnTellbold)
	ON_BN_CLICKED(IDC_TELLITALIC, OnTellitalic)
	ON_WM_DESTROY()
	ON_EN_CHANGE(IDC_SENDPREFIX, OnChangeSendprefix)
	ON_EN_CHANGE(IDC_TELLPREFIX, OnChangeTellprefix)
	ON_BN_CLICKED(IDC_COLORCHANGES, OnColorchanges)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChatWindow message handlers

UINT APIENTRY CCHookProc(HWND hdlg, UINT uiMsg, WPARAM wParam, LPARAM lParam )
{
	return 0;
}

void CChatWindow::OnTellcolor() 
{
	CColorDialog	dlg;
	COLORREF			custCols[16] = {0};

	CHOOSECOLOR	cc =
	{
		sizeof cc,
		GetSafeHwnd(),
		NULL,
		m_tellColor,
		custCols,
		CC_RGBINIT | CC_ENABLEHOOK,
		0,
		CCHookProc
	};

	dlg.m_cc = cc;

	if ( dlg.DoModal() )
	{
		m_tellColor = dlg.m_cc.rgbResult;
		m_tell.Invalidate();
	}
}

void CChatWindow::OnSendcolor() 
{
	CColorDialog	dlg;
	COLORREF			custCols[16] = {0};

	CHOOSECOLOR	cc =
	{
		sizeof cc,
		GetSafeHwnd(),
		NULL,
		m_sendColor,
		custCols,
		CC_RGBINIT | CC_ENABLEHOOK,
		0,
		CCHookProc
	};

	dlg.m_cc = cc;

	if ( dlg.DoModal() )
	{
		m_sendColor = dlg.m_cc.rgbResult;
		m_send.Invalidate();
	}
}

HBRUSH CChatWindow::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	if ( pWnd->GetSafeHwnd() == m_send.GetSafeHwnd() )
	{
		pDC->SetTextColor( m_sendColor );
		pDC->SetBkColor  ( m_backColor );
		hbr = m_hbr;
		pDC->SelectObject( m_sendFont );
	}
	else if ( pWnd->GetSafeHwnd() == m_tell.GetSafeHwnd() )
	{
		pDC->SetTextColor( m_tellColor );
		pDC->SetBkColor  ( m_backColor );
		hbr = m_hbr;
		pDC->SelectObject( m_tellFont );
	}

	return hbr;
}

void CChatWindow::OnSendbold() 
{
	m_sendbold = !m_sendbold;
	updateSendFont();
	m_send.Invalidate();
}

void CChatWindow::OnSenditalic() 
{
	m_senditalic = !m_senditalic;
	updateSendFont();
	m_send.Invalidate();
}

void CChatWindow::OnTellbold() 
{
	m_tellbold = !m_tellbold;
	updateTellFont();
	m_tell.Invalidate();
}

void CChatWindow::OnTellitalic() 
{
	m_tellitalic = !m_tellitalic;
	updateTellFont();
	m_tell.Invalidate();
}

BOOL CChatWindow::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_hbr.CreateSolidBrush( m_backColor );

	GetFont()->GetLogFont( &m_baseFont );

	updateSendFont();
	updateTellFont();

	OnChangeSendprefix();
	OnChangeTellprefix();

	OnColorchanges();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CChatWindow::updateSendFont( void )
{
	LOGFONT lf = m_baseFont;

	lf.lfWeight = m_sendbold ? 700 : 400;
	lf.lfItalic = m_senditalic;

	if ( m_sendFont )
		delete m_sendFont;

	m_sendFont = new CFont;
	m_sendFont->CreateFontIndirect( &lf );
}

void CChatWindow::updateTellFont( void )
{
	LOGFONT lf = m_baseFont;

	lf.lfWeight = m_tellbold ? 700 : 400;
	lf.lfItalic = m_tellitalic;

	if ( m_tellFont )
		delete m_tellFont;

	m_tellFont = new CFont;
	m_tellFont->CreateFontIndirect( &lf );
}

void CChatWindow::OnDestroy() 
{
	delete m_sendFont;
	delete m_tellFont;

	CDialog::OnDestroy();
}

void CChatWindow::OnChangeSendprefix() 
{
	CString prefix;

	GetDlgItem( IDC_SENDPREFIX )->GetWindowText( prefix );

	prefix += "You send";
	GetDlgItem( IDC_SENDSTATIC )->SetWindowText( prefix );
}

void CChatWindow::OnChangeTellprefix() 
{
	CString prefix;

	GetDlgItem( IDC_TELLPREFIX )->GetWindowText( prefix );

	prefix += "Dids tells you";
	GetDlgItem( IDC_TELLSTATIC )->SetWindowText( prefix );
}

void CChatWindow::OnColorchanges() 
{
	BOOL state = ((CButton *) GetDlgItem( IDC_COLORCHANGES ))->GetCheck();

	GetDlgItem( IDC_TELLCOLOR  )->EnableWindow( state );
	GetDlgItem( IDC_TELLBOLD   )->EnableWindow( state );
	GetDlgItem( IDC_TELLITALIC )->EnableWindow( state );
	GetDlgItem( IDC_TELLPREFIX )->EnableWindow( state );

	GetDlgItem( IDC_SENDCOLOR  )->EnableWindow( state );
	GetDlgItem( IDC_SENDBOLD   )->EnableWindow( state );
	GetDlgItem( IDC_SENDITALIC )->EnableWindow( state );
	GetDlgItem( IDC_SENDPREFIX )->EnableWindow( state );
}
