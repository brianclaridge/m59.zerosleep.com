// m59logDoc.h : interface of the CM59logDoc class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef M59LOGDOC_H
#define M59LOGDOC_H

#include <string.h>

const UINT MSG_DEATH			= 0x00000001;
const UINT MSG_PESPELL		= 0x00000002;
const UINT MSG_AREASPELL	= 0x00000004;
const UINT MSG_TOUCHSPELL	= 0x00000008;
const UINT MSG_FOOD			= 0x00000010;
const UINT MSG_STAFF			= 0x00000020;
const UINT MSG_SITS			= 0x00000040;
const UINT MSG_BREAK			= 0x00000080;
const UINT MSG_KILLED		= 0x00000100;
const UINT MSG_KILLEDBY		= 0x00000200;
const UINT MSG_ASSASSINS	= 0x00000400;
const UINT MSG_TOUGHER		= 0x00000800;
const UINT MSG_TOKEN			= 0x00001000;
const UINT MSG_WEAPONS		= 0x00002000;
const UINT MSG_SICKS			= 0x00004000;

const int WHITE_PLAYER	= 0;
const int ORANGE_PLAYER	= 1;
const int RED_PLAYER		= 2;

const int PKED = 0;
const int MONSTER = 1;

//template<class CString>
inline UINT AFXAPI HashKey(const CString &key)
{
    UINT hash = ~0U;
	 LPCSTR ptr = key;

    while ( *ptr )
        hash = hash * 31 + *ptr++;

    return hash;
}

class CM59logView;

struct spellPerformance
{
	int successes;
	int fails;
	int sincelast;
	int sinceprev;
	int improves;
};

struct killPerformance
{
	int kills;
	int sincelast;
	int sinceprev;
	int improves;
};

typedef CMap < CString, const CString &, int, int & > MESSAGES;
typedef CMap < CString, const CString &, spellPerformance, spellPerformance & > PESPELLS;
typedef CMap < CString, const CString &, spellPerformance, spellPerformance & > AREASPELLS;
typedef CMap < CString, const CString &, spellPerformance, spellPerformance & > TOUCHSPELLS;
typedef CMap < CString, const CString &, int, int & > KILLEDWITH;
typedef CMap < CString, const CString &, int, int & > KILLEDWHAT;
typedef CMap < CString, const CString &, int, int & > KILLEDBYWHAT;
typedef CMap < CString, const CString &, int, int & > SPITON;

class CM59logDoc : public CDocument
{
protected: // create from serialization only
	CM59logDoc();
	DECLARE_DYNCREATE(CM59logDoc)

// Attributes
public:

private:
	// Unprocessed messages
	MESSAGES m_messages;

	// Total deaths in the system
	UINT	m_totalDeaths[RED_PLAYER + 1][MONSTER + 1];

	// Total things eaten
	UINT	m_eats[ 3 ];

	// Total rests
	UINT	m_sits[ 2 ];

	// Total time logged on
	UINT	m_tottime;

	// Total staffs
	UINT	m_staff[ 2 ];

	// Time at first log on
	UINT	m_starttime;

	// Personal effect spells
	PESPELLS m_personal;

	// Area effect spells
	AREASPELLS m_area;

	// Touch spells
	TOUCHSPELLS m_touch;

	// Number of things broken
	UINT	m_broken;

	// What was killed and how?
	KILLEDWHAT m_killedwhat;
	KILLEDWITH m_killedwith;
	KILLEDBYWHAT m_killedbywhat;

	// Number of spits
	UINT	m_spits;

	// How many of each thing we've spat on
	SPITON	m_spitons;

	// Tougher stats
	killPerformance m_tougher;

	// Character name
	CString m_name;

	// Assasinated
	int	m_assassins[ 2 ];

	// Tokens
	int	m_tokens;

	// Weaponcraft skills
	killPerformance m_punch;
	killPerformance m_weapons;
	killPerformance m_dodge;

	// Sicknesses
	int	m_poisons;
	int	m_dements;

	// Last thing we killed
	CString	m_lastKill;

	void	resetAttributes();

	BOOL	processMessage( const CString &str, int count, UINT &msgType );

	BOOL	processFood( const CString &str, int count );
	BOOL	processStaff( const CString &str, int count );
	BOOL	processIgnores( const CString &str, int count );
	BOOL	processDeathNotices( const CString &str, int count );
	BOOL	processSits( const CString &str, int count );
	BOOL	processBreaks( const CString &str, int count );
	BOOL	processPersonalEffects( const CString &str, int count );
	BOOL	processAreaSpells( const CString &str, int count );
	BOOL	processTouchSpells( const CString &str, int count );
	BOOL	processKilled( const CString &str, int count );
	BOOL	processKilledBy( const CString &str, int count );
	BOOL	processSpits( const CString &str, int count );
	BOOL	processTougher( const CString &str, int count );
	BOOL	processAssassins( const CString &str, int count );
	BOOL	processTokens( const CString &str, int count );
	BOOL	processWeapons( const CString &str, int count );
	BOOL	processSicks( const CString &str, int count );

	BOOL	isMonsterAfter( const CString &str, LPCSTR message );
	BOOL	isAMonster( LPCSTR message );

// Operations
public:
	void ResetAllMessages( void ) { m_messages.RemoveAll(); }

	void AddString( LPCTSTR str, int num = 1 );

	int GetKillScore( int killed, int killer ) const { return m_totalDeaths[ killed ][ killer ]; }

	const MESSAGES &GetMessages( void ) const { return m_messages; }

	int GetEats( void ) const { return m_eats[ 0 ]; }
	int GetBeers( void ) const { return m_eats[ 1 ]; }
	int GetFulls( void ) const { return m_eats[ 2 ]; }

	int GetRests( void ) const { return m_sits[ 0 ]; }
	int GetStopRests( void ) const { return m_sits[ 1 ]; }

	int GetStartled( void ) const { return m_staff[ 0 ]; }
	int GetTaps( void ) const { return m_staff[ 1 ]; }

	int GetBreaks( void ) const { return m_broken; }

	int GetSpits( void ) const { return m_spits; }

	int GetSlainBy( void ) const { return m_assassins[ 0 ]; }
	int GetSlain( void ) const { return m_assassins[ 1 ]; }

	int GetTokens( void ) const { return m_tokens; }

	const CString &GetName( void ) const { return m_name; }
	void SetName( const CString &name ) { m_name = name; }

	killPerformance  GetTougher( void ) const { return m_tougher; }
	killPerformance  GetWeapons( void ) const { return m_weapons; }
	killPerformance  GetPunch	( void ) const { return m_punch; }
	killPerformance  GetDodge	( void ) const { return m_dodge; }

	int GetPoisons( void ) const { return m_poisons; }
	int GetDements( void ) const { return m_dements; }

	void StartClock( void )			{ m_starttime = GetTickCount() / 1000; }
	void StopClock( void )			{ m_tottime = ClockTick(); m_starttime = 0; }
	UINT ClockTick( void )  const { return m_tottime + (m_starttime == 0 ? 0 : (GetTickCount() / 1000 - m_starttime) ); }
	UINT ClockNow( void )  const { return m_starttime == 0 ? 0 : (GetTickCount() / 1000 - m_starttime); }

	const PESPELLS &GetPESpells( void ) const { return m_personal; }
	const AREASPELLS &GetAreaSpells( void ) const { return m_area; }
	const TOUCHSPELLS &GetTouchSpells( void ) const { return m_touch; }
	const KILLEDWITH &GetKilledWith( void ) const { return m_killedwith; }
	const KILLEDWHAT &GetKilledWhat( void ) const { return m_killedwhat; }
	const KILLEDBYWHAT &GetKilledByWhat( void ) const { return m_killedbywhat; }
	const SPITON &GetSpitOns( void ) const { return m_spitons; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CM59logDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CM59logDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CM59logDoc)
	afx_msg void OnConfigureYourname();
	afx_msg void OnViewUnprocessedmessages();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

BOOL	FindInTable( LPCSTR message, const char *table[], int *index = NULL );
BOOL	FindMonsterIndex( LPCSTR message, int *index );
BOOL	FindKilledWithIndex( LPCSTR message, int *index );
BOOL	FindKilledByIndex( LPCSTR message, int *index );
BOOL	FindPESpellIndex( LPCSTR message, int *index );
BOOL	FindAreaSpellIndex( LPCSTR message, int *index );
BOOL	FindTouchSpellIndex( LPCSTR message, int *index );

/////////////////////////////////////////////////////////////////////////////

#endif // M59LOGDOC_H
