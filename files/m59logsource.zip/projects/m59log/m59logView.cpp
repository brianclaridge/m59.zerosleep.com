// m59logView.cpp : implementation of the CM59logView class
//

#include "stdafx.h"
#include "m59log.h"

#include "m59logDoc.h"
#include "m59logView.h"

#include <vector>
#include <algorithm>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const UINT IDD_LISTBOX = 1;
const UINT IDD_TREE = 2;

const LPARAM TID_DEATH    = 0x0001;

const LPARAM TID_DEATHWHITE			= 0x0100;
const LPARAM TID_DEATHWHITEPK			= 0x0101;
const LPARAM TID_DEATHWHITEMONSTER	= 0x0102;
const LPARAM TID_DEATHWHITETOT		= 0x0103;
const LPARAM TID_DEATHORANGE			= 0x0110;
const LPARAM TID_DEATHORANGEPK		= 0x0111;
const LPARAM TID_DEATHORANGEMONSTER	= 0x0112;
const LPARAM TID_DEATHORANGETOT		= 0x0113;
const LPARAM TID_DEATHRED				= 0x0120;
const LPARAM TID_DEATHREDPK			= 0x0121;
const LPARAM TID_DEATHREDMONSTER		= 0x0122;
const LPARAM TID_DEATHREDTOT			= 0x0123;

const LPARAM TID_EDIBLE   = 0x0002;

const LPARAM TID_EDIBLEFOOD   = 0x0201;
const LPARAM TID_EDIBLEBEER   = 0x0202;
const LPARAM TID_EDIBLEGLUT	= 0x0203;

const LPARAM TID_TOUGHER  = 0x0003;

const LPARAM TID_TOUGHERSINCE = 0x0301;
const LPARAM TID_TOUGHERPREV  = 0x0302;
const LPARAM TID_TOUGHERAVE	= 0x0303;

const LPARAM TID_PESPELLS = 0x0004;

const LPARAM TID_PESUCCESS = 0x10000;
const LPARAM TID_PEFAIL		= 0x20000;
const LPARAM TID_PELAST		= 0x30000;
const LPARAM TID_PEPREV		= 0x40000;
const LPARAM TID_PEAVE		= 0x50000;

const LPARAM TID_KILLS    = 0x0005;
const LPARAM TID_KILLWITH = 0x0006;
const LPARAM TID_KILLEDBY = 0x0007;

const LPARAM TID_REST     = 0x0008;

const LPARAM TID_RESTREST  = 0x0801;
const LPARAM TID_RESTSTOP	= 0x0802;

const LPARAM TID_STAFF    = 0x0009;

const LPARAM TID_STAFFTAPS		= 0x0901;
const LPARAM TID_STAFFSTART	= 0x0902;

const LPARAM TID_BREAKS			= 0x000A;
const LPARAM TID_SPITS			= 0x000B;
const LPARAM TID_AREASPELLS	= 0x000C;

const LPARAM TID_ASSASSINS		= 0x000D;
const LPARAM TID_ASSFOR			= 0x0D01;
const LPARAM TID_ASSAGAINST	= 0x0D02;

const LPARAM TID_TOUCHSPELLS	= 0x000E;
const LPARAM TID_TOKENS			= 0x000F;

const LPARAM TID_WEAPONCRAFT	= 0x0010;
const LPARAM TID_WEAPON			= 0x0011;
const LPARAM TID_WEAPONSINCE	= 0x1101;
const LPARAM TID_WEAPONPREV	= 0x1102;
const LPARAM TID_WEAPONAVE		= 0x1103;
const LPARAM TID_PUNCH			= 0x0012;
const LPARAM TID_PUNCHSINCE	= 0x1201;
const LPARAM TID_PUNCHPREV		= 0x1202;
const LPARAM TID_PUNCHAVE		= 0x1203;
const LPARAM TID_DODGE			= 0x0013;
const LPARAM TID_DODGESINCE	= 0x1301;
const LPARAM TID_DODGEPREV		= 0x1302;
const LPARAM TID_DODGEAVE		= 0x1303;

const LPARAM TID_POISONS		= 0x0014;
const LPARAM TID_DEMENTS		= 0x0015;

extern CM59logApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CM59logView

IMPLEMENT_DYNCREATE(CM59logView, CView)

BEGIN_MESSAGE_MAP(CM59logView, CView)
	//{{AFX_MSG_MAP(CM59logView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_COPYALLSUBTREE, OnEditCopyallsubtree)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPYALLSUBTREE, OnUpdateEditCopyallsubtree)
	ON_COMMAND(ID_EDIT_COPYCOMPLETETREE, OnEditCopycompletetree)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CM59logView construction/destruction

CM59logView::CM59logView()
{
	m_systemmessage = FALSE;
}

CM59logView::~CM59logView()
{
}

BOOL CM59logView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CM59logView drawing

void CM59logView::OnDraw(CDC* pDC)
{
	CM59logDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CM59logView diagnostics

#ifdef _DEBUG
void CM59logView::AssertValid() const
{
	CView::AssertValid();
}

void CM59logView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CM59logDoc* CM59logView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CM59logDoc)));
	return (CM59logDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CM59logView message handlers

void CM59logView::SetCharFormat( UINT flags, const CHARFORMAT *fmt, COLORREF purpleColor )
{
	if ( ( fmt->dwMask & CFM_COLOR ) && (fmt->crTextColor & 0xffffff) == purpleColor )
		m_systemmessage = TRUE;
	else
		m_systemmessage = FALSE;
}

void CM59logView::ReplaceSel( LPCTSTR str )
{
	// For now
	if ( m_systemmessage )
	{
		GetDocument()->AddString( str );

		m_systemmessage = FALSE;
	}
}

int CM59logView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CRect rect;
	GetClientRect( &rect );

	m_tree.Create( TVS_DISABLEDRAGDROP | TVS_LINESATROOT | TVS_HASBUTTONS |
							TVS_HASLINES | WS_BORDER | WS_CHILD | WS_VSCROLL | WS_VISIBLE,
						rect,
						this,
						IDD_TREE );

	resetTree();

	return 0;
}

void CM59logView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	CRect rect( 0, 0, cx, cy );

	m_tree.MoveWindow( rect );
}

void CM59logView::resetTree( void ) 
{
	m_tree.DeleteAllItems();
	m_rootitem = TVI_ROOT; //*/ m_tree.InsertItem( "Your stats", TVI_ROOT );
	m_deaths = m_tree.InsertItem( "Death Stats", m_rootitem );
	m_spells = m_tree.InsertItem( "Spell Stats", m_rootitem );
	m_misc = m_tree.InsertItem( "Misc Stats", m_rootitem );
}

void CM59logView::OnUpdate(CView* , LPARAM hint, CObject* ) 
{
	if ( hint == HINT_RESET_CONTENT )
		resetTree();

	if ( hint & MSG_DEATH )
		doTotalDeathScore();

	if ( hint & MSG_KILLED )
	{
		doKillWhat();
		doKillWith();
	}

	if ( hint & MSG_KILLEDBY )
		doKilledByWhat();

	if ( hint & MSG_TOUGHER )
		doTougher();

	if ( hint & MSG_ASSASSINS )
		doAssassins();

	if ( hint & MSG_PESPELL )
		doPESpells();

	if ( hint & MSG_AREASPELL )
		doAreaSpells();

	if ( hint & MSG_TOUCHSPELL )
		doTouchSpells();

	if ( hint & MSG_WEAPONS )
		doWeapons();

	if ( hint & MSG_FOOD )
		doFood();

	if ( hint & MSG_SITS )
		doRests();

	if ( hint & MSG_BREAK )
		doBreaks();

	if ( hint & MSG_TOKEN )
		doTokens();

	if ( hint & MSG_STAFF )
		doStaff();

	if ( hint & MSG_SICKS )
		doSicks();
}

HTREEITEM CM59logView::insertItem(	const CString	&str,
												HTREEITEM		parentitem,
												LPARAM			lParamID )
{
	HTREEITEM child = m_tree.GetRootItem();
	TV_ITEM	item = { TVIF_CHILDREN, parentitem };

	if ( child != NULL &&
			m_tree.GetItem( &item ) &&
			item.cChildren > 0 &&
			( child = m_tree.GetChildItem( parentitem ) ) != NULL )
	{
		do
		{
			if ( (LPARAM) m_tree.GetItemData( child ) == lParamID )
			{
				m_tree.SetItem( child, TVIF_TEXT, str, 0, 0, 0, 0, 0 );
				return child;
			}
		} while ( ( child = m_tree.GetNextSiblingItem( child ) ) != NULL );
	}

	child = m_tree.InsertItem( str, parentitem );

	m_tree.SetItemData( child, lParamID );

	return child;
}

void CM59logView::doFood() 
{
	int eats = GetDocument()->GetEats();
	int beers = GetDocument()->GetBeers();
	int total = eats + beers;
	int fulls = GetDocument()->GetFulls();

	CString fmt;
	fmt.Format( "Total Edibles: %d", total );

	HTREEITEM ediblenode = insertItem( fmt, m_misc, TID_EDIBLE );

	if ( ediblenode )
	{
		fmt.Format( "Food: %d, %d%%", eats, total ? (eats * 100) / total : 0 );
		insertItem( fmt, ediblenode, TID_EDIBLEFOOD );

		fmt.Format( "Beer: %d, %d%%", beers, total ? (beers * 100) / total : 0 );
		insertItem( fmt, ediblenode, TID_EDIBLEBEER );

		fmt.Format( "Gluttony attempts: %d, %d%%", fulls, total ? (fulls * 100) / total : 0 );
		insertItem( fmt, ediblenode, TID_EDIBLEGLUT );
	}
}

void CM59logView::doTougher() 
{
	CString fmt;
	fmt.Format( "Toughers" );

	HTREEITEM toughnode = insertItem( fmt, m_deaths, TID_TOUGHER );

	if ( toughnode )
	{
		killPerformance kill = GetDocument()->GetTougher();

		fmt.Format( "Kills since last tougher: %d", kill.sincelast );
		insertItem( fmt, toughnode, TID_TOUGHERSINCE );

		fmt.Format( "Kills for previous tougher: %d", kill.sinceprev );
		insertItem( fmt, toughnode, TID_TOUGHERPREV );

		fmt.Format( "Average for all toughers: %.2f", kill.improves ? (double) kill.kills / kill.improves : 0 );
		insertItem( fmt, toughnode, TID_TOUGHERAVE );
	}
}

void CM59logView::doWeapons() 
{
	CString fmt;
	fmt.Format( "Weaponcraft" );

	HTREEITEM weaponcraftnode = insertItem( fmt, m_deaths, TID_WEAPONCRAFT );

	if ( weaponcraftnode )
	{
		doKillPerf( GetDocument()->GetWeapons(),	"Weapons",	weaponcraftnode, TID_WEAPON );
		doKillPerf( GetDocument()->GetPunch(),		"Fists",		weaponcraftnode, TID_PUNCH );
		doKillPerf( GetDocument()->GetDodge(),		"Dodging",	weaponcraftnode, TID_DODGE );
	}
}

void CM59logView::doKillPerf
(
	const killPerformance	&kills,
	LPCSTR						text,
	HTREEITEM					parent,
	LPARAM						nodeID
)
{
	HTREEITEM killnode = insertItem( text, parent, nodeID );

	if ( killnode )
	{
		CString fmt;

		fmt.Format( "Kills since last improve: %d", kills.sincelast );
		insertItem( fmt, killnode, (nodeID << 8) + 1 );

		fmt.Format( "Kills for previous improve: %d", kills.sinceprev );
		insertItem( fmt, killnode, (nodeID << 8) + 2 );

		fmt.Format( "Average for all improves: %.2f", kills.improves ? (double) kills.kills / kills.improves : 0 );
		insertItem( fmt, killnode, (nodeID << 8) + 3 );
	}
}

void CM59logView::doAssassins()
{
	CString fmt;
	fmt.Format( "Assassins game" );

	HTREEITEM assnode = insertItem( fmt, m_misc, TID_ASSASSINS );

	if ( assnode )
	{
		CString string;

		fmt.Format( "Assassinated: %d", GetDocument()->GetSlain() );
		insertItem( fmt, assnode, TID_ASSFOR );

		fmt.Format( "Assassinated by: %d", GetDocument()->GetSlainBy() );
		insertItem( fmt, assnode, TID_ASSAGAINST );
	}
}

void CM59logView::doPESpells() 
{
	CString fmt;
	fmt.Format( "Personal effect spells" );

	HTREEITEM pespellsnode = insertItem( fmt, m_spells, TID_PESPELLS );

	if ( pespellsnode )
	{
		const PESPELLS &spells = GetDocument()->GetPESpells();
		POSITION pos = spells.GetStartPosition();
		CString string;
		spellPerformance spell;

		while ( pos )
		{
			spells.GetNextAssoc( pos, string, spell );

			int total = spell.successes + spell.fails;
			HTREEITEM spellnode;

			int index;
			FindPESpellIndex( " " + string, &index );

			// Don't add spells that we have never cast
			if ( total &&
				( spellnode = insertItem( string, pespellsnode, ( TID_PESPELLS << 8 ) + index ) ) )
			{

				fmt.Format( "Successes: %d, %d%%", spell.successes, total ? (spell.successes * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_PESPELLS << 8 ) + index + TID_PESUCCESS );

				fmt.Format( "Fails: %d, %d%%", spell.fails, total ? (spell.fails * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_PESPELLS << 8 ) + index + TID_PEFAIL );

				fmt.Format( "Successes since last improve: %d", spell.sincelast );
				insertItem( fmt, spellnode, ( TID_PESPELLS << 8 ) + index + TID_PELAST );

				fmt.Format( "Successes for previous improve: %d", spell.sinceprev );
				insertItem( fmt, spellnode, ( TID_PESPELLS << 8 ) + index + TID_PEPREV );

				fmt.Format( "Average for all improves: %.2f", spell.improves ? (double) spell.successes / spell.improves : 0 );
				insertItem( fmt, spellnode, ( TID_PESPELLS << 8 ) + index + TID_PEAVE );
			}
		}
	}
}

void CM59logView::doAreaSpells() 
{
	CString fmt;
	fmt.Format( "Area effect spells" );

	HTREEITEM areaspellsnode = insertItem( fmt, m_spells, TID_AREASPELLS );

	if ( areaspellsnode )
	{
		const AREASPELLS &spells = GetDocument()->GetAreaSpells();
		POSITION pos = spells.GetStartPosition();
		CString string;
		spellPerformance spell;

		while ( pos )
		{
			spells.GetNextAssoc( pos, string, spell );

			int total = spell.successes + spell.fails;
			HTREEITEM spellnode;

			int index;
			FindAreaSpellIndex( " " + string, &index );

			// Don't add spells that we have never cast, or ones that
			// we have never failed and never improved in
			if ( ( spell.improves > 0 || spell.fails > 0 ) &&
				( spellnode = insertItem( string, areaspellsnode, ( TID_AREASPELLS << 8 ) + index ) ) )
			{

				fmt.Format( "Successes: %d, %d%%", spell.successes, total ? (spell.successes * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_AREASPELLS << 8 ) + index + TID_PESUCCESS );

				fmt.Format( "Fails: %d, %d%%", spell.fails, total ? (spell.fails * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_AREASPELLS << 8 ) + index + TID_PEFAIL );

				fmt.Format( "Successes since last improve: %d", spell.sincelast );
				insertItem( fmt, spellnode, ( TID_AREASPELLS << 8 ) + index + TID_PELAST );

				fmt.Format( "Successes for previous improve: %d", spell.sinceprev );
				insertItem( fmt, spellnode, ( TID_AREASPELLS << 8 ) + index + TID_PEPREV );

				fmt.Format( "Average for all improves: %.2f", spell.improves ? (double) spell.successes / spell.improves : 0 );
				insertItem( fmt, spellnode, ( TID_AREASPELLS << 8 ) + index + TID_PEAVE );
			}
		}
	}
}

void CM59logView::doTouchSpells() 
{
	CString fmt;
	fmt.Format( "Touch spells" );

	HTREEITEM touchspellsnode = insertItem( fmt, m_spells, TID_TOUCHSPELLS );

	if ( touchspellsnode )
	{
		const TOUCHSPELLS &spells = GetDocument()->GetTouchSpells();
		POSITION pos = spells.GetStartPosition();
		CString string;
		spellPerformance spell;

		while ( pos )
		{
			spells.GetNextAssoc( pos, string, spell );

			int total = spell.successes + spell.fails;
			HTREEITEM spellnode;

			int index;
			FindTouchSpellIndex( " " + string, &index );

			// Don't add spells that we have never cast
			if ( total &&
				( spellnode = insertItem( string, touchspellsnode, ( TID_TOUCHSPELLS << 8 ) + index ) ) )
			{

				fmt.Format( "Successes: %d, %d%%", spell.successes, total ? (spell.successes * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_TOUCHSPELLS << 8 ) + index + TID_PESUCCESS );

				fmt.Format( "Fails: %d, %d%%", spell.fails, total ? (spell.fails * 100) / total : 0 );
				insertItem( fmt, spellnode, ( TID_TOUCHSPELLS << 8 ) + index + TID_PEFAIL );

				fmt.Format( "Successes since last improve: %d", spell.sincelast );
				insertItem( fmt, spellnode, ( TID_TOUCHSPELLS << 8 ) + index + TID_PELAST );

				fmt.Format( "Successes for previous improve: %d", spell.sinceprev );
				insertItem( fmt, spellnode, ( TID_TOUCHSPELLS << 8 ) + index + TID_PEPREV );

				fmt.Format( "Average for all improves: %.2f", spell.improves ? (double) spell.successes / spell.improves : 0 );
				insertItem( fmt, spellnode, ( TID_TOUCHSPELLS << 8 ) + index + TID_PEAVE );
			}
		}
	}
}

class KILLS
{
public:
	KILLS()
		: kills(0), nodeID(0), str("") {}
	KILLS( int k, LPARAM id, const CString &s)
		: kills(k), nodeID(id), str(s) {}

	int		kills;
	LPARAM	nodeID;
	CString	str;

public:
	friend bool operator < (const KILLS &k1, const KILLS &k2 )
	{
		return k1.kills < k2.kills;
	}
	friend bool operator == (const KILLS &k1, const KILLS &k2 )
	{
		return k1.kills == k2.kills && k1.nodeID == k2.nodeID;
	}
};

void CM59logView::doKillWhat()
{
	CString fmt;
	fmt.Format( "Personal kills recorded" );

	HTREEITEM killsnode = insertItem( fmt, m_deaths, TID_KILLS );

	int totkills = 0;

	if ( killsnode )
	{
		const KILLEDWHAT &what = GetDocument()->GetKilledWhat();
		POSITION pos = what.GetStartPosition();
		CString string;

		std::vector< KILLS > killdata;

		while ( pos )
		{
			int kills;
			what.GetNextAssoc( pos, string, kills );

			int index;
			FindMonsterIndex( " " + string, &index );

			KILLS thiskill( kills, ( TID_KILLS << 8 ) + index, string );
			killdata.push_back( thiskill );

			totkills += kills;
		}

		std::sort( killdata.begin(), killdata.end() );

		for ( int i = killdata.size() - 1; i >= 0; i-- )
		{
			const KILLS &thiskill = killdata[ i ];

			fmt.Format( "%s: %d, %d%%",
							thiskill.str,
							thiskill.kills,
							totkills ? (thiskill.kills * 100) / totkills : 0 );

			insertItem( fmt, killsnode, thiskill.nodeID );
		}
	}

	fmt.Format( "Kills recorded: %d", totkills );
	m_tree.SetItem( killsnode, TVIF_TEXT, fmt, 0, 0, 0, 0, 0 );

	UINT spits = GetDocument()->GetSpits();

	fmt.Format( "Spitting: %d, %d%%", spits, totkills? (spits * 100) / totkills : 0 );
	HTREEITEM spitnode = insertItem( fmt, m_deaths, TID_SPITS );

	if ( spitnode )
	{
		const SPITON &spitons = GetDocument()->GetSpitOns();
		POSITION pos = spitons.GetStartPosition();
		CString string;

		// Should use another class other than KILL here, but WTF
		std::vector< KILLS > spitdata;

		while ( pos )
		{
			int spits;
			spitons.GetNextAssoc( pos, string, spits );

			int index;
			FindMonsterIndex( string, &index );

			KILLS thisspit( spits, ( TID_SPITS << 8 ) + index, string );
			spitdata.push_back( thisspit );
		}

		std::sort( spitdata.begin(), spitdata.end() );

		const KILLEDWHAT &what = GetDocument()->GetKilledWhat();

		for ( int i = spitdata.size() - 1; i >= 0; i-- )
		{
			const KILLS &thisspit = spitdata[ i ];

			int totkills;

			if ( !what.Lookup( thisspit.str.Mid( 1 ), totkills ) )
				totkills = 0;

			fmt.Format( "%s: %d, Spit/kill: %d%%",
							thisspit.str.Mid( 1 ),
							thisspit.kills, // really spits
							totkills ? (thisspit.kills * 100) / totkills : 0 );

			insertItem( fmt, spitnode, thisspit.nodeID );
		}
	}
}

void CM59logView::doKillWith()
{
	CString fmt;
	fmt.Format( "Killed with" );

	HTREEITEM killsnode = insertItem( fmt, m_deaths, TID_KILLWITH );

	int totkills = 0;

	if ( killsnode )
	{
		const KILLEDWITH &with = GetDocument()->GetKilledWith();
		POSITION pos = with.GetStartPosition();
		CString string;

		std::vector< KILLS > killdata;

		while ( pos )
		{
			int kills;
			with.GetNextAssoc( pos, string, kills );

			int index;
			FindKilledWithIndex( " " + string, &index );

			KILLS thiskill( kills, ( TID_KILLWITH << 8 ) + index, string );
			killdata.push_back( thiskill );

			totkills += kills;
		}

		std::sort( killdata.begin(), killdata.end() );

		for ( int i = killdata.size() - 1; i >= 0; i-- )
		{
			const KILLS &thiskill = killdata[ i ];

			fmt.Format( "%s: %d, %d%%",
							thiskill.str,
							thiskill.kills,
							totkills ? (thiskill.kills * 100) / totkills : 0 );

			insertItem( fmt, killsnode, thiskill.nodeID );
		}
	}

	fmt.Format( "Killed with: %d", totkills );
	m_tree.SetItem( killsnode, TVIF_TEXT, fmt, 0, 0, 0, 0, 0 );
}

void CM59logView::doKilledByWhat()
{
	CString fmt;
	fmt.Format( "Killed by" );

	HTREEITEM killsnode = insertItem( fmt, m_deaths, TID_KILLEDBY );

	int totkills = 0;

	if ( killsnode )
	{
		const KILLEDBYWHAT &what = GetDocument()->GetKilledByWhat();
		POSITION pos = what.GetStartPosition();
		CString string;

		std::vector< KILLS > killdata;

		while ( pos )
		{
			int kills;
			what.GetNextAssoc( pos, string, kills );

			int index;
			FindKilledByIndex( " " + string, &index );

			KILLS thiskill( kills, ( TID_KILLWITH << 8 ) + index, string );
			killdata.push_back( thiskill );

			totkills += kills;
		}

		std::sort( killdata.begin(), killdata.end() );

		for ( int i = killdata.size() - 1; i >= 0; i-- )
		{
			const KILLS &thiskill = killdata[ i ];

			fmt.Format( "%s: %d",
							thiskill.str,
							thiskill.kills );

			insertItem( fmt, killsnode, thiskill.nodeID );
		}
	}

	fmt.Format( "Killed by: %d", totkills );
	m_tree.SetItem( killsnode, TVIF_TEXT, fmt, 0, 0, 0, 0, 0 );
}

void CM59logView::doRests() 
{
	int rests = GetDocument()->GetRests();
	int stops = GetDocument()->GetStopRests();

	CString fmt( "Rests" );

	HTREEITEM restnode = insertItem( fmt, m_misc, TID_REST );

	if ( restnode )
	{
		fmt.Format( "Resting: %d", rests );
		insertItem( fmt, restnode, TID_RESTREST );

		fmt.Format( "Stop Resting: %d", stops );
		insertItem( fmt, restnode, TID_RESTSTOP );
	}
}

void CM59logView::doStaff() 
{
	int taps = GetDocument()->GetTaps() * 3;
	int startled = GetDocument()->GetStartled();

	CString fmt;
	fmt.Format( "Staff tapping" );

	HTREEITEM staffnode = insertItem( fmt, m_misc, TID_STAFF );

	if ( staffnode )
	{
		fmt.Format( "Taps heard: %d", taps );
		insertItem( fmt, staffnode, TID_STAFFTAPS );

		fmt.Format( "People Startled: %d", startled );
		insertItem( fmt, staffnode, TID_STAFFSTART );
	}
}

void CM59logView::doSicks() 
{
	CString fmt;
	fmt.Format( "Poisonings: %d", GetDocument()->GetPoisons() );
	insertItem( fmt, m_misc, TID_POISONS );

	fmt.Format( "Dements: %d", GetDocument()->GetDements() );
	insertItem( fmt, m_misc, TID_DEMENTS );
}

const char *killedType	  [] = { "White", "Orange", "Red" };
const char *killerType	  [] = { "PKed", "Eaten by Monsters" };
const LPARAM killedTypeTID[] = { TID_DEATHWHITE, TID_DEATHORANGE, TID_DEATHRED };
const LPARAM scorecardTID[ RED_PLAYER + 1 ][ MONSTER + 2 ] =
	{
		{ TID_DEATHWHITEPK,	TID_DEATHWHITEMONSTER,	TID_DEATHWHITETOT },
		{ TID_DEATHORANGEPK,	TID_DEATHORANGEMONSTER, TID_DEATHORANGETOT },
		{ TID_DEATHREDPK,		TID_DEATHREDMONSTER,		TID_DEATHREDTOT }
	};

void CM59logView::doTotalDeathScore() 
{
	int scorecard[ RED_PLAYER + 2 ][ MONSTER + 2 ] = {0};
	int total = 0;

	for ( int i = WHITE_PLAYER; i <= RED_PLAYER; i++ )
	{
		for ( int j = PKED; j <= MONSTER; j++ )
		{
			int kills = GetDocument()->GetKillScore( i, j );

			scorecard[i][j]					 = kills;
			scorecard[RED_PLAYER + 1][j]	+= kills;
			scorecard[i][MONSTER + 1]		+= kills;
			total									+= kills;
		}
	}

	CString fmt;
	fmt.Format( "Total Server Deaths: %d", total );

	HTREEITEM deathnode = insertItem( fmt, m_deaths, TID_DEATH );

	if ( deathnode )
	{
		for ( int i = WHITE_PLAYER; i <= RED_PLAYER; i++ )
		{
			fmt.Format(	"%s Players: %d", killedType[ i ], scorecard[ i ][ MONSTER + 1 ] );

			HTREEITEM subnode = insertItem( fmt, deathnode, killedTypeTID[ i ] );

			for ( int j = PKED; subnode && j <= MONSTER; j++ )
			{
				fmt.Format(	"%s: %d",
								killerType[ j ],
								scorecard[ i ][ j ] );

				insertItem( fmt, subnode, scorecardTID[ i ][ j ] );
			}
		}
	}
}

void CM59logView::doBreaks() 
{
	CString fmt;
	fmt.Format( "Things broken: %d", GetDocument()->GetBreaks() );

	insertItem( fmt, m_misc, TID_BREAKS );
}

void CM59logView::doTokens() 
{
	CString fmt;
	fmt.Format( "Tokens found: %d", GetDocument()->GetTokens() );

	insertItem( fmt, m_misc, TID_TOKENS );
}

void CM59logView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();

	RECT rect;
	BOOL maxed;
	static BOOL firstTime = TRUE;

	if ( firstTime )
	{
		if ( theApp.GetRect( &rect ) && theApp.GetMaxed( &maxed ) )
		{
			if ( maxed )
				GetTopLevelParent()->ShowWindow( SW_SHOWMAXIMIZED );
			else
				GetTopLevelParent()->MoveWindow( rect.left,
															rect.top,
															rect.right - rect.left,
															rect.bottom - rect.top );
		}

		firstTime = FALSE;
	}
}

// Depth-first tree traversal
void CM59logView::getTreeText( HTREEITEM root, CString &text, bool skipClosed, int depth )
{
	CString nodeText;

	nodeText = m_tree.GetItemText( root );

	for ( int i = 0; i < depth; i++ )
		text += "  ";

	text += nodeText;
	text += "\r\n";


	if ( ( !skipClosed || (m_tree.GetItemState( root, TVIS_EXPANDED ) | TVIS_EXPANDED) ) &&
			m_tree.ItemHasChildren( root ) &&
			(root = m_tree.GetChildItem( root )) != NULL )
	{
		do
		{
			getTreeText( root, text, skipClosed, depth + 1 );

		} while ( (root = m_tree.GetNextSiblingItem( root )) != NULL );
	}
}

void CM59logView::OnEditCopy() 
{
	HTREEITEM root = m_tree.GetSelectedItem();

	if ( root )
	{
		CString text;

		getTreeText( root, text, true, 0 );

		putOnClipboard( text );
	}
}

void CM59logView::putOnClipboard( const CString &text )
{
	if ( OpenClipboard() )
	{
		if ( EmptyClipboard() )
		{
			HGLOBAL hText = GlobalAlloc(	GMEM_MOVEABLE | GMEM_DDESHARE,
													text.GetLength() + 1 );

			if ( hText )
			{
				strcpy( reinterpret_cast<char *>( GlobalLock( hText ) ), text );

				GlobalUnlock( hText );

				if ( !SetClipboardData( CF_TEXT, hText ) )
					GlobalFree( hText );
			}
		}

		CloseClipboard();
	}
}

void CM59logView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_tree.GetSelectedItem() != NULL );
}

void CM59logView::OnEditCopyallsubtree() 
{
	HTREEITEM root = m_tree.GetSelectedItem();

	if ( root )
	{
		CString text;

		getTreeText( root, text, false, 0 );

		putOnClipboard( text );
	}
}

void CM59logView::OnUpdateEditCopyallsubtree(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_tree.GetSelectedItem() != NULL );
}

void CM59logView::OnEditCopycompletetree() 
{
	CString text;

	getTreeText( m_deaths, text, false, 0 );
	getTreeText( m_spells, text, false, 0 );
	getTreeText( m_misc,   text, false, 0 );

	putOnClipboard( text );
}
