#if !defined(AFX_YOURNAMEDLG_H__65FA12A0_D090_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
#define AFX_YOURNAMEDLG_H__65FA12A0_D090_11D0_AAC6_0000E8CDA5DB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// YourNameDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CYourNameDlg dialog

class CYourNameDlg : public CDialog
{
// Construction
public:
	CYourNameDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CYourNameDlg)
	enum { IDD = IDD_YOURNAME };
	CString	m_name;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYourNameDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CYourNameDlg)
	afx_msg void OnChangeYourname();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YOURNAMEDLG_H__65FA12A0_D090_11D0_AAC6_0000E8CDA5DB__INCLUDED_)
