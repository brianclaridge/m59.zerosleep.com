// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"

#include <time.h>

#include "m59log.h"

#include "MainFrm.h"

#include "m59logDoc.h"
#include "m59logView.h"

#include "ChooseM59Window.h"
#include "ChatWindow.h"

#include "PMRstSub.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CM59logApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_TOGGLELOGGING, OnTogglelogging)
	ON_UPDATE_COMMAND_UI(ID_TOGGLELOGGING, OnUpdateTogglelogging)
	ON_WM_TIMER()
	ON_COMMAND(ID_VIEW_MIDNIGHTATEVENHOURS, OnViewMidnightatevenhours)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MIDNIGHTATEVENHOURS, OnUpdateViewMidnightatevenhours)
	ON_WM_CLOSE()
	ON_COMMAND(ID_LOG_RECORDTODISK, OnLogRecordtodisk)
	ON_UPDATE_COMMAND_UI(ID_LOG_RECORDTODISK, OnUpdateLogRecordtodisk)
	ON_COMMAND(ID_CONFIGURE_AUTOCONNECTTOMERIDIAN, OnConfigureAutoconnecttomeridian)
	ON_UPDATE_COMMAND_UI(ID_CONFIGURE_AUTOCONNECTTOMERIDIAN, OnUpdateConfigureAutoconnecttomeridian)
	ON_COMMAND(ID_VIEW_LOGGEDMERIDIAN59WINDOW, OnViewLoggedmeridian59window)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LOGGEDMERIDIAN59WINDOW, OnUpdateViewLoggedmeridian59window)
	ON_COMMAND(ID_CONFIGURE_CHATWINDOW, OnConfigureChatwindow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_INDICATOR_TIMEON,
	ID_INDICATOR_MERTIME,
	ID_INDICATOR_THISTIMEON,
	ID_SEPARATOR           // status line indicator
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_setChar = RegisterWindowMessage( "M59HOOK_EM_SETCHARFORMAT" );
	m_replaceSel = RegisterWindowMessage( "M59HOOK_EM_REPLACESEL" );

	m_logtodisk = FALSE;
	m_logpurple = FALSE;
}

CMainFrame::~CMainFrame()
{
	OnLogStoplogging();
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	// One minute every 5 seconds, so tick every 2.5s
	SetTimer( ID_INDICATOR_MERTIME, 2500, NULL );

	OnTimer( ID_INDICATOR_MERTIME );

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

LRESULT CMainFrame::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	if ( message == WM_COPYDATA )
	{
		COPYDATASTRUCT *cds = (COPYDATASTRUCT *) lParam;

		// Bit set, we have EM_SETCHARFORMAT
		if ( cds->dwData & 0x80000000 )
			processSetCharFormat( cds->dwData & 0x7fffffff, (CHARFORMAT *) cds->lpData );
		else
			processReplaceSel( cds->dwData, (LPCTSTR) cds->lpData );
	}

	return CFrameWnd::WindowProc(message, wParam, lParam);
}

void CMainFrame::processSetCharFormat( UINT flags, CHARFORMAT *fmt )
{
	((CM59logView *) GetActiveView())->SetCharFormat( flags, fmt, theApp.GetPurpleColor() );
}

void CMainFrame::processReplaceSel( BOOL canUndo, LPCTSTR str )
{
	((CM59logView *) GetActiveView())->ReplaceSel( str );

	if ( m_logtodisk )
	{
		m_logfile.Write( str, strlen( str ) );
		m_logfile.Flush();
	}
}

BOOL CMainFrame::tryConnectTo( HWND editWnd )
{
	BOOL ok = FALSE;

	if ( editWnd != NULL )
	{
		ok = SubclassRichEdit( GetSafeHwnd(), editWnd, GetCurrentThreadId() );

		if ( ok )
		{
			CDocument *doc = GetActiveDocument();

			if ( doc->IsKindOf( RUNTIME_CLASS( CM59logDoc ) ) )
			{
				// We've connected!
				CM59logDoc *m59doc = (CM59logDoc *) GetActiveDocument();
				m59doc->StartClock();
			}
			else
			{
				ok = FALSE;
			}
		}
	}

	m_richEdit = ( ok ? editWnd : NULL );

	return ok;
}

BOOL CMainFrame::FindM59Window( bool displayDialog )
{
	BOOL ok = FALSE;
	HWND after = NULL;

	HWND possibleWnds[ MAX_M59_INSTANCES ] = { 0 };
	int possible = 0;

	// First, how many candidates do we have?
	while ( possible < 10 && (after = FindWindowEx( NULL, after, "Meridian 59", NULL )) != NULL )
	{
		// As we can have more than one Meridian window now, check each for an existing connection
		possibleWnds[ possible ] = ::GetDlgItem( after, 0x3ED );

		if ( possibleWnds[ possible ] != NULL )
		{
			// Has it already been subclassed?
			if ( IsSubclassed( possibleWnds[ possible ] ) )
				// Yes, reject
				possibleWnds[ possible ] = NULL;
			else
				// No, it's a candidate
				possible++;
		}
	}

	m_richEdit = NULL;

	if ( possible == 0 )
		// No candidates - fail
		ok = FALSE;
	else if ( possible == 1 )
	{
		// One candidate - try to connect
		ok = tryConnectTo( possibleWnds[ possible - 1 ] );
	}
	else if ( displayDialog )
	{
		// More than one, do the connect dialog if interactive
		CChooseM59Window dlg;

		dlg.SetPossibles( possibleWnds, possible );

		if ( dlg.DoModal() == IDOK )
			ok = tryConnectTo( possibleWnds[ dlg.GetSelected() ] );
	}
	else // >1 Merdian, no display dialog - fail
		ok = FALSE;

	return ok;
}

BOOL CMainFrame::OnLogStartlogging() 
{
	BOOL ok;

	OnLogStoplogging();

	ok = FindM59Window( true );

	if ( !ok )
	{
		if ( m_richEdit == NULL )
			AfxMessageBox( "Didn't find a Meridian 59 Window", MB_OK | MB_ICONSTOP );
		else
			AfxMessageBox( "Oops, unknown error :-(", MB_OK | MB_ICONSTOP );
	}

	return ok;
}

BOOL CMainFrame::OnLogStoplogging() 
{
	if ( g_hHook != NULL )
	{
		CDocument *doc = GetActiveDocument();

		if ( doc && doc->IsKindOf( RUNTIME_CLASS( CM59logDoc ) ) )
		{
			CM59logDoc *m59doc = (CM59logDoc *) GetActiveDocument();
			m59doc->StopClock();
		}

		if ( m_logtodisk )
			OnLogRecordtodisk();

		UnsubclassRichEdit( m_richEdit );

		g_hHook = NULL;
		m_richEdit = NULL;
	}

	return g_hHook == NULL;
}

void CMainFrame::OnTogglelogging() 
{
	BOOL ok;

	if ( m_logpurple )
		ok = OnLogStoplogging();
	else
		ok = OnLogStartlogging();

	if ( ok )
		m_logpurple = !m_logpurple;
}

void CMainFrame::OnUpdateTogglelogging(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck( m_logpurple );
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	if ( nIDEvent == ID_INDICATOR_MERTIME )
	{
		// Do the Meridian time clock first
		time_t now = time( NULL );
		struct tm tm = *localtime( &now );
		BOOL is_pm = tm.tm_hour % 2;
		if ( !theApp.GetEvenHours() )
			is_pm = !is_pm;

		int hour = tm.tm_min / 5;
		int min = (tm.tm_min % 5) * 12 + tm.tm_sec / 5;

		CString fmt;
		fmt.Format( "Now: %02d:%02d", hour + is_pm * 12, min );

		int index = m_wndStatusBar.CommandToIndex( ID_INDICATOR_MERTIME );
		m_wndStatusBar.SetPaneText( index, fmt );

		// Do the logged on clock time now
		CDocument *doc = GetActiveDocument();

		UINT secs = 0;
		UINT thissecs = 0;

		if ( doc && doc->IsKindOf( RUNTIME_CLASS( CM59logDoc ) ) )
		{
			secs = ((CM59logDoc *) GetActiveDocument())->ClockTick();
			thissecs = ((CM59logDoc *) GetActiveDocument())->ClockNow();

			if ( !IsWindow( m_richEdit ) )
			{
				if ( m_logpurple )
					OnTogglelogging();
				else
				{
					if ( theApp.GetAutoConnect() && FindM59Window( false ) )
						OnTogglelogging();
				}
			}
		}

		fmt.Format( "Tot: %04d:%02d", secs / 3600, (secs / 60) % 60 );

		index = m_wndStatusBar.CommandToIndex( ID_INDICATOR_TIMEON );
		m_wndStatusBar.SetPaneText( index, fmt );

		fmt.Format( "Sess: %02d:%02d", thissecs / 3600, (thissecs / 60) % 60 );

		index = m_wndStatusBar.CommandToIndex( ID_INDICATOR_THISTIMEON );
		m_wndStatusBar.SetPaneText( index, fmt );
	}

	CFrameWnd::OnTimer(nIDEvent);
}

void CMainFrame::OnClose() 
{
	RECT	rect;
	GetWindowRect( &rect );

	theApp.SaveState( &rect, IsZoomed() );

	if ( m_logpurple )
		OnTogglelogging();

	CFrameWnd::OnClose();
}

void CMainFrame::OnLogRecordtodisk() 
{
	BOOL ok = FALSE;

	if ( !m_logtodisk )
	{
		CFileDialog dlg( TRUE, NULL, "logfile.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, NULL, this );

		if ( dlg.DoModal() == IDOK )
		{
			CString path = dlg.GetPathName();

			if ( m_logfile.Open(	path,
										CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite ) )
			{
				m_logfile.SeekToEnd();

				ok = TRUE;
			}
		}
  	}
	else
	{
		m_logfile.Close();

		ok = TRUE;
	}

	if ( ok )
		m_logtodisk = !m_logtodisk;
}

void CMainFrame::OnUpdateLogRecordtodisk(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_logpurple );
	pCmdUI->SetCheck( m_logtodisk );
}

void CMainFrame::OnViewMidnightatevenhours() 
{
	theApp.ToggleEvenHours();
	OnTimer( ID_INDICATOR_MERTIME );
}

void CMainFrame::OnUpdateViewMidnightatevenhours(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck( theApp.GetEvenHours() );
}

void CMainFrame::OnConfigureAutoconnecttomeridian() 
{
	theApp.ToggleAutoConnect();
}

void CMainFrame::OnUpdateConfigureAutoconnecttomeridian(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck( theApp.GetAutoConnect() );
}

void CMainFrame::OnViewLoggedmeridian59window() 
{
	if ( m_richEdit )
	{
		::ShowWindow( ::GetParent( m_richEdit ), SW_SHOWNORMAL );
		::BringWindowToTop( ::GetParent( m_richEdit ) );
	}
}

void CMainFrame::OnUpdateViewLoggedmeridian59window(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable( m_richEdit != NULL );
}

void CMainFrame::OnConfigureChatwindow() 
{
	CChatWindow dlg;
	COLORREF sendColor, tellColor;
	BOOL sendbold, senditalic;
	BOOL tellbold, tellitalic;
	char sendPrefix[PREFIX_LENGTH];
	char tellPrefix[PREFIX_LENGTH];

	GetSendOptions( &sendColor, &sendbold, &senditalic, sendPrefix );
	GetTellOptions( &tellColor, &tellbold, &tellitalic, tellPrefix );

	dlg.SetFilter( GetFilterMessages() );
	dlg.SetBackColor( theApp.GetBackColor() );
	dlg.SetSendOptions( sendColor, sendbold, senditalic, sendPrefix );
	dlg.SetTellOptions( tellColor, tellbold, tellitalic, tellPrefix );

	if ( dlg.DoModal() == IDOK )
	{
		SetFilterMessages( dlg.GetFilter() );

		dlg.GetSendOptions( &sendColor, &sendbold, &senditalic, sendPrefix );
		dlg.GetTellOptions( &tellColor, &tellbold, &tellitalic, tellPrefix );

		SetSendOptions( sendColor, sendbold, senditalic, sendPrefix );
		SetTellOptions( tellColor, tellbold, tellitalic, tellPrefix );
	}
}
